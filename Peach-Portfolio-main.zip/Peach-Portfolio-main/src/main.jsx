import { createRoot } from 'react-dom/client'
import '@fontsource-variable/bricolage-grotesque'
import '@fontsource-variable/dm-sans'
import '@fontsource/caveat/500.css'
import '@fontsource/caveat/700.css'
import './styles/global.css'
import App from './App.jsx'

createRoot(document.getElementById('root')).render(<App />)

"use client";

import { Suspense, useEffect, useRef, useState } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import {
  useGLTF,
  Environment,
  ContactShadows,
  Float,
  useTexture,
  Preload,
} from "@react-three/drei";
import * as THREE from "three";

/* ─────────────────────────────────────────────────
   SHOE + SISCO BRANDING
───────────────────────────────────────────────── */
function ShoeScene() {
  const { scene } = useGLTF("/models/shoe/shoe.gltf") as any;
  const logoTex = useTexture("/images/logo.png");
  const normalTex = useTexture("/models/shoe/normal.jpg");
  const aoTex = useTexture("/models/shoe/occlusionRougnessMetalness.jpg");

  const didApply = useRef(false);

  useEffect(() => {
    if (!scene || didApply.current) return;
    didApply.current = true;

    // Collect all meshes
    const meshes: THREE.Mesh[] = [];
    scene.traverse((obj: any) => {
      if (obj.isMesh) {
        obj.castShadow = true;
        obj.receiveShadow = true;
        meshes.push(obj);
      }
    });

    // Sort largest → smallest by vertex count
    meshes.sort(
      (a, b) =>
        (b.geometry?.attributes?.position?.count ?? 0) -
        (a.geometry?.attributes?.position?.count ?? 0)
    );

    // ── Body (index 0) — Sisco electric blue ──
    if (meshes[0]) {
      meshes[0].material = new THREE.MeshStandardMaterial({
        color: new THREE.Color("#3a7fff"),
        roughness: 0.2,
        metalness: 0.22,
        normalMap: normalTex,
        normalScale: new THREE.Vector2(1, 1),
        aoMap: aoTex,
        aoMapIntensity: 0.75,
        envMapIntensity: 3.0,
      });
    }

    // ── Sole (index 1) — deep navy ──
    if (meshes[1]) {
      meshes[1].material = new THREE.MeshStandardMaterial({
        color: new THREE.Color("#08102a"),
        roughness: 0.5,
        metalness: 0.08,
        envMapIntensity: 0.9,
      });
    }

    // ── Laces + other parts (index 2+) — off-white ──
    meshes.slice(2).forEach((m) => {
      m.material = new THREE.MeshStandardMaterial({
        color: new THREE.Color("#e8eeff"),
        roughness: 0.45,
        metalness: 0.0,
        envMapIntensity: 0.7,
      });
    });

    // ── Sisco Logo — overlay on the body mesh ──
    if (meshes[0]) {
      const bodyMat = meshes[0].material as THREE.MeshStandardMaterial;

      // Create canvas with logo
      const canvas = document.createElement("canvas");
      canvas.width = 1024;
      canvas.height = 1024;
      const ctx = canvas.getContext("2d")!;

      // Blue base matching the shoe
      ctx.fillStyle = "#3a7fff";
      ctx.fillRect(0, 0, 1024, 1024);

      const img = new Image();
      img.crossOrigin = "anonymous";
      img.onload = () => {
        // Draw AO texture first
        // Draw logo in the heel / side area
        const logoSize = 240;
        const cx = 1024 / 2 - logoSize / 2;
        const cy = 1024 / 2 - logoSize / 2;
        ctx.globalAlpha = 0.85;
        ctx.drawImage(img, cx, cy, logoSize, logoSize);

        // Add "SISCO" text below logo
        ctx.globalAlpha = 0.9;
        ctx.fillStyle = "#ffffff";
        ctx.font = "bold 90px Arial";
        ctx.textAlign = "center";
        ctx.letterSpacing = "12px";
        ctx.fillText("SISCO", 512, cy + logoSize + 80);

        const logoCanvasTex = new THREE.CanvasTexture(canvas);
        logoCanvasTex.needsUpdate = true;
        bodyMat.map = logoCanvasTex;
        bodyMat.needsUpdate = true;
      };
      img.src = "/images/logo.png";
    }
  }, [scene, normalTex, aoTex, logoTex]);

  return (
    <primitive
      object={scene}
      scale={[6.0, 6.0, 6.0]}
      position={[0.4, -1.0, 0]}
      rotation={[0.05, -0.55, 0.02]}
    />
  );
}

/* ─────────────────────────────────────────────────
   CURSOR-TRACKED ROTATION RIG
───────────────────────────────────────────────── */
function RotationRig({
  mouseX,
  mouseY,
}: {
  mouseX: number;
  mouseY: number;
}) {
  const groupRef = useRef<THREE.Group>(null);
  const idleTime = useRef(0);
  const lastMouse = useRef({ x: 0, y: 0 });

  useFrame((state, delta) => {
    if (!groupRef.current) return;
    const t = state.clock.elapsedTime;

    const moved =
      Math.abs(mouseX - lastMouse.current.x) > 0.001 ||
      Math.abs(mouseY - lastMouse.current.y) > 0.001;

    if (moved) {
      idleTime.current = 0;
      lastMouse.current = { x: mouseX, y: mouseY };
    } else {
      idleTime.current += delta;
    }

    const idleSpin =
      idleTime.current > 2.5 ? Math.sin(t * 0.18) * 0.12 : 0;

    // Smooth lerp — feels like spring without extra deps
    const ease = 1 - Math.pow(0.022, delta);
    groupRef.current.rotation.x = THREE.MathUtils.lerp(
      groupRef.current.rotation.x,
      mouseY * 0.32,
      ease
    );
    groupRef.current.rotation.y = THREE.MathUtils.lerp(
      groupRef.current.rotation.y,
      mouseX * 0.62 + idleSpin,
      ease
    );
  });

  return (
    <group ref={groupRef}>
      <Float
        speed={1.3}
        rotationIntensity={0.03}
        floatIntensity={0.4}
        floatingRange={[-0.07, 0.07]}
      >
        <ShoeScene />
      </Float>
    </group>
  );
}

/* ─────────────────────────────────────────────────
   CINEMATIC STUDIO LIGHTING
───────────────────────────────────────────────── */
function Lighting() {
  return (
    <>
      {/* Key — warm white from upper-right */}
      <spotLight
        position={[6, 10, 5]}
        angle={0.25}
        penumbra={0.9}
        intensity={100}
        color="#fff5e8"
        castShadow
        shadow-mapSize={[2048, 2048]}
        shadow-bias={-0.0002}
      />
      {/* Rim — Sisco blue from behind */}
      <spotLight
        position={[-6, 5, -6]}
        angle={0.5}
        penumbra={1.0}
        intensity={65}
        color="#4f8cff"
      />
      {/* Low front fill */}
      <pointLight position={[2, -1, 5]} intensity={20} color="#d0deff" />
      {/* Top bounce */}
      <pointLight position={[0, 6, 0]} intensity={15} color="#ffffff" />
      <ambientLight intensity={0.3} color="#08102a" />
    </>
  );
}

/* ─────────────────────────────────────────────────
   LOADING STATE
───────────────────────────────────────────────── */
function Loader() {
  const ref = useRef<THREE.Mesh>(null);
  useFrame((_, d) => {
    if (ref.current) ref.current.rotation.z -= d * 2;
  });
  return (
    <mesh ref={ref}>
      <torusGeometry args={[0.8, 0.05, 16, 80]} />
      <meshStandardMaterial
        color="#4f8cff"
        emissive="#4f8cff"
        emissiveIntensity={0.6}
      />
    </mesh>
  );
}

/* ─────────────────────────────────────────────────
   MAIN EXPORT
───────────────────────────────────────────────── */
export function HeroShoe3D() {
  const [mouse, setMouse] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const onMove = (e: MouseEvent) => {
      setMouse({
        x: (e.clientX / window.innerWidth - 0.5) * 2,
        y: -(e.clientY / window.innerHeight - 0.5) * 2,
      });
    };
    const onGyro = (e: DeviceOrientationEvent) => {
      setMouse({
        x: Math.max(-1, Math.min(1, (e.gamma ?? 0) / 40)),
        y: Math.max(-1, Math.min(1, ((e.beta ?? 0) - 20) / 40)),
      });
    };
    window.addEventListener("mousemove", onMove);
    window.addEventListener("deviceorientation", onGyro);
    return () => {
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("deviceorientation", onGyro);
    };
  }, []);

  return (
    <div className="absolute inset-0">
      <Canvas
        shadows
        dpr={[1, 2]}
        camera={{ position: [0, 0.8, 5.5], fov: 36 }}
        gl={{
          antialias: true,
          alpha: true,
          toneMapping: THREE.ACESFilmicToneMapping,
          toneMappingExposure: 1.5,
        }}
        style={{ background: "transparent" }}
      >
        <Suspense fallback={<Loader />}>
          <Lighting />
          {/* "studio" env gives clean neutral reflections */}
          <Environment preset="studio" />
          <RotationRig mouseX={mouse.x} mouseY={mouse.y} />
          {/* Contact shadow pool under shoe */}
          <ContactShadows
            position={[0, -1.65, 0]}
            opacity={0.8}
            scale={12}
            blur={3.5}
            far={5}
            color="#000820"
          />
        </Suspense>
        <Preload all />
      </Canvas>
    </div>
  );
}

useGLTF.preload("/models/shoe/shoe.gltf");

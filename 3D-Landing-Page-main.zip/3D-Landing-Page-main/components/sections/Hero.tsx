"use client";

import { motion } from "framer-motion";
import { SplitText } from "@/components/ui/SplitText";
import { MagneticButton } from "@/components/ui/MagneticButton";
import { FloatingParticles } from "@/components/ui/FloatingParticles";
import { HeroTiltShoe } from "@/components/sections/HeroTiltShoe";

export function Hero() {
  return (
    <section
      id="top"
      className="relative flex min-h-[100svh] flex-col items-center justify-center overflow-hidden"
    >
      {/* Grid backdrop */}
      <div className="absolute inset-0 -z-10">
        <div className="grid-lines absolute inset-0 opacity-30" />
        {/* Ambient background glow */}
        <div
          className="absolute left-1/2 top-1/3 h-[60vh] w-[60vh] -translate-x-1/2 rounded-full blur-[120px] animate-pulse-glow"
          style={{
            opacity: 0.25,
            background:
              "radial-gradient(circle, rgba(79,140,255,0.5), transparent 70%)",
          }}
        />
      </div>

      {/* ── Tilt-card shoe — fills the center behind the text ── */}
      <div className="absolute inset-0 z-0">
        <HeroTiltShoe />
      </div>

      {/* Floating particles */}
      <div className="pointer-events-none absolute inset-0 z-[1]">
        <FloatingParticles count={55} opacity={0.35} />
      </div>

      {/* Soft vignette so headline stays legible */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 z-[2]"
        style={{
          background:
            "radial-gradient(ellipse 75% 60% at 50% 50%, transparent 25%, rgb(var(--bg) / 0.65) 75%)",
        }}
      />

      {/* ── Text overlay ── */}
      <div className="container-x pointer-events-none relative z-10 px-6 text-center">
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.8 }}
          className="eyebrow mx-auto mb-6"
        >
          <span className="h-1.5 w-1.5 rounded-full bg-neon" />
          Sisco Performance — 2026
        </motion.p>

        <h1 className="heading-xl mx-auto max-w-5xl">
          <SplitText text="Move Beyond" by="words" delay={0.5} />
          <br />
          <span className="text-gradient animate-gradient-pan">
            <SplitText text="Limits." by="chars" delay={0.9} stagger={0.06} />
          </span>
        </h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.2, duration: 0.8 }}
          className="mx-auto mt-6 max-w-xl text-base text-[rgb(var(--muted))] md:text-lg"
        >
          Performance engineered. Style perfected.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.5, duration: 0.8 }}
          className="pointer-events-auto mt-10 flex flex-wrap items-center justify-center gap-4"
        >
          <MagneticButton href="#collections" variant="primary">
            Shop Now
          </MagneticButton>
          <MagneticButton href="#showcase" variant="ghost">
            Explore Collection →
          </MagneticButton>
        </motion.div>
      </div>

      {/* Scroll indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 2, duration: 1 }}
        className="absolute bottom-8 left-1/2 z-10 flex -translate-x-1/2 flex-col items-center gap-2 text-[rgb(var(--muted))]"
      >
        <span className="text-[10px] uppercase tracking-[0.3em]">Scroll</span>
        <span className="flex h-9 w-5 justify-center rounded-full border border-[rgb(var(--border)/0.3)] p-1">
          <motion.span
            animate={{ y: [0, 10, 0] }}
            transition={{ duration: 1.6, repeat: Infinity, ease: "easeInOut" }}
            className="h-1.5 w-1 rounded-full bg-electric"
          />
        </span>
      </motion.div>
    </section>
  );
}

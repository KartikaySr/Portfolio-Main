"use client";

import { useCallback, useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { TESTIMONIALS } from "@/lib/data";
import { SplitText } from "@/components/ui/SplitText";
import { GlassCard } from "@/components/ui/GlassCard";
import { useReducedMotion } from "@/hooks/useReducedMotion";

export function Testimonials() {
  const [index, setIndex] = useState(0);
  const [direction, setDirection] = useState(1);
  const reduced = useReducedMotion();

  const paginate = useCallback((dir: number) => {
    setDirection(dir);
    setIndex((i) => (i + dir + TESTIMONIALS.length) % TESTIMONIALS.length);
  }, []);

  // Auto-advance carousel (paused for reduced motion).
  useEffect(() => {
    if (reduced) return;
    const id = window.setInterval(() => paginate(1), 5000);
    return () => window.clearInterval(id);
  }, [paginate, reduced]);

  const t = TESTIMONIALS[index];

  return (
    <section className="section-pad relative overflow-hidden">
      <div className="container-x">
        <div className="mx-auto mb-14 max-w-2xl text-center">
          <p className="eyebrow mx-auto mb-4 justify-center">
            <span className="h-1.5 w-1.5 rounded-full bg-neon" />
            Loved by athletes
          </p>
          <h2 className="heading-lg">
            <SplitText text="Trusted at every pace" by="words" onScroll />
          </h2>
        </div>

        <div className="relative mx-auto max-w-3xl">
          <div className="relative min-h-[280px]">
            <AnimatePresence custom={direction} mode="wait">
              <motion.div
                key={t.id}
                custom={direction}
                initial={{ opacity: 0, x: reduced ? 0 : direction * 80 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: reduced ? 0 : direction * -80 }}
                transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
              >
                <GlassCard className="p-8 md:p-12">
                  <div className="flex items-center gap-1 text-neon" aria-label={`${t.rating} out of 5 stars`}>
                    {Array.from({ length: 5 }).map((_, i) => (
                      <span key={i} className={i < t.rating ? "" : "opacity-25"}>
                        ★
                      </span>
                    ))}
                  </div>

                  <blockquote className="mt-6 font-display text-2xl font-medium leading-snug md:text-3xl">
                    “{t.quote}”
                  </blockquote>

                  <div className="mt-8 flex items-center gap-4">
                    <span
                      className="grid h-12 w-12 place-items-center rounded-full font-semibold text-ink"
                      style={{ backgroundColor: t.accent }}
                      aria-hidden
                    >
                      {t.initials}
                    </span>
                    <div>
                      <p className="font-semibold">{t.name}</p>
                      <p className="text-sm text-[rgb(var(--muted))]">{t.role}</p>
                    </div>
                  </div>
                </GlassCard>
              </motion.div>
            </AnimatePresence>
          </div>

          {/* Controls */}
          <div className="mt-8 flex items-center justify-center gap-4">
            <button
              type="button"
              onClick={() => paginate(-1)}
              aria-label="Previous testimonial"
              className="grid h-10 w-10 place-items-center rounded-full border border-[rgb(var(--border)/0.2)] transition-colors hover:border-[rgb(var(--fg)/0.4)]"
            >
              ←
            </button>

            <div className="flex gap-2" role="tablist" aria-label="Testimonials">
              {TESTIMONIALS.map((item, i) => (
                <button
                  key={item.id}
                  type="button"
                  role="tab"
                  aria-selected={i === index}
                  aria-label={`Go to testimonial ${i + 1}`}
                  onClick={() => {
                    setDirection(i > index ? 1 : -1);
                    setIndex(i);
                  }}
                  className={`h-2 rounded-full transition-all ${
                    i === index
                      ? "w-8 bg-electric"
                      : "w-2 bg-[rgb(var(--border)/0.3)]"
                  }`}
                />
              ))}
            </div>

            <button
              type="button"
              onClick={() => paginate(1)}
              aria-label="Next testimonial"
              className="grid h-10 w-10 place-items-center rounded-full border border-[rgb(var(--border)/0.2)] transition-colors hover:border-[rgb(var(--fg)/0.4)]"
            >
              →
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}

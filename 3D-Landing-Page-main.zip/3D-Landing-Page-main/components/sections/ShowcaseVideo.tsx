"use client";

import { useEffect, useRef, useState } from "react";
import { useReducedMotion } from "@/hooks/useReducedMotion";

type ShowcaseVideoProps = {
  /** Base path without extension, e.g. /videos/showcase-airx */
  src: string;
  poster: string;
  label: string;
};

/**
 * Looping turntable clip of a real Sisco sneaker, cut out onto a studio
 * backdrop. Mirrors the hero video treatment: autoplays muted, loops, and
 * falls back to a static poster under reduced-motion. Only starts playing
 * once it scrolls into view so three off-screen clips never fight for
 * decode bandwidth on load.
 */
export function ShowcaseVideo({ src, poster, label }: ShowcaseVideoProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const reduced = useReducedMotion();
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const v = videoRef.current;
    if (!v || reduced) return;

    // If the clip is already decodable by the time this effect runs, the
    // onCanPlay React event may have fired before the handler attached — flip
    // ready here so the element (and its poster) never gets stuck invisible.
    if (v.readyState >= 2) setReady(true);

    // Pause when scrolled away, resume when visible — keeps playback smooth
    // by only ever decoding the clips the user can actually see.
    const io = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) v.play().catch(() => undefined);
        else v.pause();
      },
      { threshold: 0.25 }
    );
    io.observe(v);
    return () => io.disconnect();
  }, [reduced]);

  if (reduced) {
    return (
      // eslint-disable-next-line @next/next/no-img-element
      <img
        src={poster}
        alt={label}
        className="h-full w-full object-cover"
      />
    );
  }

  return (
    <video
      ref={videoRef}
      className={`h-full w-full object-cover transition-opacity duration-700 ${
        ready ? "opacity-100" : "opacity-0"
      }`}
      muted
      loop
      playsInline
      preload="metadata"
      poster={poster}
      aria-label={label}
      onCanPlay={() => setReady(true)}
    >
      <source src={`${src}.webm`} type="video/webm" />
      <source src={`${src}.mp4`} type="video/mp4" />
    </video>
  );
}

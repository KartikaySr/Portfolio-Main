"use client";

import Image from "next/image";
import { NAV_LINKS } from "@/lib/data";

const SOCIALS = [
  { label: "Instagram", href: "#", glyph: "◈" },
  { label: "X / Twitter", href: "#", glyph: "✕" },
  { label: "YouTube", href: "#", glyph: "▶" },
  { label: "TikTok", href: "#", glyph: "♪" },
];

const SHOP_LINKS = ["Air X", "Velocity", "Nova", "Gift cards"];
const SUPPORT_LINKS = ["Shipping", "Returns", "Size guide", "Contact"];

export function Footer() {

  return (
    <footer className="relative overflow-hidden border-t border-[rgb(var(--border)/0.1)] px-6 pb-10 pt-20 md:px-10 lg:px-16">
      <div
        aria-hidden
        className="pointer-events-none absolute -bottom-40 left-1/2 h-80 w-[80vw] -translate-x-1/2 rounded-full bg-electric/10 blur-[120px]"
      />
      <div className="container-x">
        <div className="grid grid-cols-2 gap-10 md:grid-cols-4 lg:grid-cols-5">
          {/* Brand */}
          <div className="col-span-2 lg:col-span-2">
            <a
              href="#top"
              className="flex items-center gap-2 text-2xl font-semibold tracking-tightest"
            >
              <div className="relative h-9 w-9 overflow-hidden rounded-lg">
                <Image
                  src="/images/logo.png"
                  alt="Sisco Logo"
                  fill
                  className="object-cover scale-150"
                />
              </div>
              <span className="font-display">SISCO</span>
            </a>
            <p className="mt-4 max-w-xs text-sm text-[rgb(var(--muted))]">
              Performance engineered. Style perfected. Built for the next
              kilometer.
            </p>

            <div className="mt-6 flex gap-3">
              {SOCIALS.map((s) => (
                <a
                  key={s.label}
                  href={s.href}
                  aria-label={s.label}
                  className="grid h-10 w-10 place-items-center rounded-full border border-[rgb(var(--border)/0.2)] text-[rgb(var(--muted))] transition-all hover:-translate-y-1 hover:border-electric hover:text-electric"
                >
                  <span aria-hidden>{s.glyph}</span>
                </a>
              ))}
            </div>
          </div>

          {/* Explore */}
          <nav aria-label="Footer — explore">
            <h3 className="text-sm font-semibold">Explore</h3>
            <ul className="mt-4 space-y-3 text-sm text-[rgb(var(--muted))]">
              {NAV_LINKS.map((l) => (
                <li key={l.href}>
                  <a
                    href={l.href}
                    className="transition-colors hover:text-[rgb(var(--fg))]"
                  >
                    {l.label}
                  </a>
                </li>
              ))}
            </ul>
          </nav>

          {/* Shop */}
          <nav aria-label="Footer — shop">
            <h3 className="text-sm font-semibold">Shop</h3>
            <ul className="mt-4 space-y-3 text-sm text-[rgb(var(--muted))]">
              {SHOP_LINKS.map((l) => (
                <li key={l}>
                  <a
                    href="#collections"
                    className="transition-colors hover:text-[rgb(var(--fg))]"
                  >
                    {l}
                  </a>
                </li>
              ))}
            </ul>
          </nav>

          {/* Support + contact */}
          <nav aria-label="Footer — support">
            <h3 className="text-sm font-semibold">Support</h3>
            <ul className="mt-4 space-y-3 text-sm text-[rgb(var(--muted))]">
              {SUPPORT_LINKS.map((l) => (
                <li key={l}>
                  <a
                    href="#"
                    className="transition-colors hover:text-[rgb(var(--fg))]"
                  >
                    {l}
                  </a>
                </li>
              ))}
              <li>
                <a
                  href="https://github.com/Jishnu09-siuu/3D-Landing-Page#readme"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="transition-colors hover:text-[rgb(var(--fg))] text-electric font-medium"
                >
                  GitHub README ↗
                </a>
              </li>
              <li>
                <a
                  href="mailto:hello@sisco.example"
                  className="transition-colors hover:text-[rgb(var(--fg))]"
                >
                  hello@sisco.example
                </a>
              </li>
            </ul>
          </nav>
        </div>

        {/* Big wordmark */}
        <div
          aria-hidden
          className="pointer-events-none mt-16 select-none text-center font-display font-bold tracking-tightest text-[rgb(var(--fg)/0.04)]"
          style={{ fontSize: "clamp(4rem, 18vw, 16rem)", lineHeight: 0.8 }}
        >
          SISCO
        </div>

        <div className="mt-8 flex flex-col items-center justify-between gap-4 border-t border-[rgb(var(--border)/0.1)] pt-8 text-sm text-[rgb(var(--muted))] md:flex-row">
          <p>© {new Date().getFullYear()} Sisco. All rights reserved.</p>
          <div className="flex gap-6">
            <a href="#" className="transition-colors hover:text-[rgb(var(--fg))]">
              Privacy
            </a>
            <a href="#" className="transition-colors hover:text-[rgb(var(--fg))]">
              Terms
            </a>
            <a href="#" className="transition-colors hover:text-[rgb(var(--fg))]">
              Cookies
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}

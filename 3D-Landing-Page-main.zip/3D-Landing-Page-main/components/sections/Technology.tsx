"use client";

import { useEffect, useRef } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { FEATURES } from "@/lib/data";
import { SplitText } from "@/components/ui/SplitText";
import { useReducedMotion } from "@/hooks/useReducedMotion";

export function Technology() {
  const root = useRef<HTMLDivElement>(null);
  const reduced = useReducedMotion();

  useEffect(() => {
    if (reduced || !root.current) return;
    gsap.registerPlugin(ScrollTrigger);

    const ctx = gsap.context(() => {
      const cards = gsap.utils.toArray<HTMLElement>("[data-feature]");
      cards.forEach((card, i) => {
        gsap.from(card, {
          y: 60,
          opacity: 0,
          duration: 0.9,
          ease: "power3.out",
          scrollTrigger: {
            trigger: card,
            start: "top 88%",
            once: true,
          },
          delay: (i % 2) * 0.08,
        });
      });
    }, root);

    return () => ctx.revert();
  }, [reduced]);

  return (
    <section
      id="technology"
      ref={root}
      className="section-pad relative overflow-hidden"
    >
      {/* subtle animated backdrop */}
      <div
        className="absolute left-1/2 top-0 -z-10 h-[50vh] w-[80vw] -translate-x-1/2 rounded-full opacity-20 blur-[140px]"
        style={{
          background:
            "radial-gradient(circle, rgba(79,140,255,0.6), transparent 70%)",
        }}
      />

      <div className="container-x">
        <div className="mx-auto mb-16 max-w-3xl text-center">
          <p className="eyebrow mx-auto mb-4 justify-center">
            <span className="h-1.5 w-1.5 rounded-full bg-neon" />
            Technology
          </p>
          <h2 className="heading-lg">
            <SplitText
              text="Innovation you can feel"
              by="words"
              onScroll
            />
          </h2>
          <p className="mx-auto mt-5 max-w-xl text-[rgb(var(--muted))]">
            Four breakthroughs working as one system — tuned for energy return,
            stability, breathability and speed.
          </p>
        </div>

        <div className="mx-auto grid max-w-4xl grid-cols-1 gap-x-14 gap-y-10 sm:grid-cols-2">
          {FEATURES.map((f) => (
            <div
              key={f.id}
              data-feature
              className="group flex gap-4 border-t border-[rgb(var(--border)/0.15)] pt-6"
            >
              {/* simple bullet marker */}
              <span
                aria-hidden
                className="mt-1.5 h-2.5 w-2.5 shrink-0 rounded-full bg-electric transition-transform duration-300 group-hover:scale-125"
              />

              <div>
                <div className="flex items-baseline justify-between gap-4">
                  <h3 className="font-display text-xl font-semibold text-[rgb(var(--fg))]">
                    {f.title}
                  </h3>
                  <span className="shrink-0 text-sm font-medium text-electric">
                    {f.metric}
                  </span>
                </div>
                <p className="mt-2 text-[rgb(var(--muted))]">{f.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

"use client";

import { useRef } from "react";
import {
  motion,
  useScroll,
  useTransform,
  useSpring,
  type MotionValue,
} from "framer-motion";
import { FEATURED_SHOES, type Shoe } from "@/lib/data";
import { SplitText } from "@/components/ui/SplitText";
import { Reveal } from "@/components/ui/Reveal";

/* ------------------------------------------------------------------ */
/*  Per-card scroll transform config                                    */
/* ------------------------------------------------------------------ */
type CardConfig = {
  xIn: number;      // X offset when entering from below
  xOut: number;     // X offset when leaving at top
  yIn: number;      // Y offset when entering
  yOut: number;     // Y offset when leaving
  rotateIn: number; // rotation on entry
  rotateOut: number;
  scaleIn: number;  // scale on entry
};

const CARD_CONFIGS: CardConfig[] = [
  // Left — Air X: flies in from the left
  { xIn: -240, xOut: -160, yIn: 0,   yOut: 0,   rotateIn: -8, rotateOut: -4, scaleIn: 0.88 },
  // Center — Velocity: rises from below
  { xIn: 0,    xOut: 0,    yIn: 110, yOut: -70, rotateIn: 0,  rotateOut: 0,  scaleIn: 0.82 },
  // Right — Nova: flies in from the right
  { xIn: 240,  xOut: 160,  yIn: 0,   yOut: 0,   rotateIn: 8,  rotateOut: 4,  scaleIn: 0.88 },
];

/* ------------------------------------------------------------------ */
/*  Section                                                             */
/* ------------------------------------------------------------------ */
export function Showcase() {
  const sectionRef = useRef<HTMLElement>(null);

  // Track raw scroll progress of the section through the viewport
  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ["start end", "end start"],
  });

  // Smooth out jitter for a buttery feel
  const smooth = useSpring(scrollYProgress, { stiffness: 40, damping: 30, restDelta: 0.001 });

  return (
    <section id="showcase" ref={sectionRef} className="section-pad relative">
      <div className="container-x">
        {/* Section header */}
        <div className="mb-16 flex flex-col items-start justify-between gap-6 md:flex-row md:items-end">
          <div>
            <p className="eyebrow mb-4">
              <span className="h-1.5 w-1.5 rounded-full bg-neon" />
              Featured
            </p>
            <h2 className="heading-lg max-w-2xl">
              <SplitText
                text="Three silhouettes. One obsession."
                by="words"
                onScroll
              />
            </h2>
          </div>
          <Reveal direction="up" delay={0.2}>
            <p className="max-w-sm text-[rgb(var(--muted))]">
              Each pair engineered to perform — and perfected to be seen.
            </p>
          </Reveal>
        </div>

        {/* Cards — scroll-animated */}
        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {FEATURED_SHOES.map((shoe, i) => (
            <AnimatedShoeCard
              key={shoe.id}
              shoe={shoe}
              index={i}
              scrollProgress={smooth}
              config={CARD_CONFIGS[i]}
            />
          ))}
        </div>
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/*  Animated wrapper — drives x / y / rotate / scale / opacity         */
/* ------------------------------------------------------------------ */
function AnimatedShoeCard({
  shoe,
  index,
  scrollProgress,
  config,
}: {
  shoe: Shoe;
  index: number;
  scrollProgress: MotionValue<number>;
  config: CardConfig;
}) {
  // Stagger: each card uses a slightly shifted window so they feel sequential
  const stagger  = index * 0.03;
  const inStart  = 0.03 + stagger;
  const inEnd    = 0.32 + stagger;
  const outStart = 0.65 - stagger;
  const outEnd   = 0.97 - stagger;

  const inputRange = [inStart, inEnd, outStart, outEnd];

  const x       = useTransform(scrollProgress, inputRange, [config.xIn,      0, 0, config.xOut]);
  const y       = useTransform(scrollProgress, inputRange, [config.yIn,      0, 0, config.yOut]);
  const rotate  = useTransform(scrollProgress, inputRange, [config.rotateIn, 0, 0, config.rotateOut]);
  const scale   = useTransform(scrollProgress, inputRange, [config.scaleIn,  1, 1, 0.92]);
  const opacity = useTransform(scrollProgress, inputRange, [0, 1, 1, 0.3]);

  // Glow halo: peaks when the card is fully settled in view
  const glowOpacity = useTransform(
    scrollProgress,
    [inEnd, (inEnd + outStart) / 2, outStart],
    [0, 0.6, 0]
  );

  return (
    <motion.div
      style={{ x, y, rotate, scale, opacity }}
      className="relative will-change-transform"
    >
      {/* Accent glow halo that pulses while in view */}
      <motion.div
        aria-hidden
        style={{
          opacity: glowOpacity,
          background: `radial-gradient(circle at 50% 60%, ${shoe.gradient[1]}60, transparent 68%)`,
        }}
        className="pointer-events-none absolute -inset-6 -z-10 rounded-[2rem] blur-2xl"
      />

      <ShoeCard shoe={shoe} />
    </motion.div>
  );
}

/* ------------------------------------------------------------------ */
/*  Card UI — unchanged visual design                                   */
/* ------------------------------------------------------------------ */
function ShoeCard({ shoe }: { shoe: Shoe }) {
  return (
    <div className="group relative overflow-hidden rounded-3xl border border-[rgb(var(--border)/0.1)] bg-[rgb(var(--card)/0.4)] p-3 transition-colors hover:border-[rgb(var(--border)/0.25)]">
      {/* Gradient image stage */}
      <div
        className="relative aspect-[4/3] overflow-hidden rounded-2xl"
        style={{
          background: `linear-gradient(135deg, ${shoe.gradient[0]}, ${shoe.gradient[1]})`,
        }}
      >
        {/* Shine sweep on hover */}
        <span className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/25 to-transparent transition-transform duration-700 group-hover:translate-x-full" />

        {/* Floor shadow */}
        <span
          aria-hidden
          className="absolute bottom-4 left-1/2 h-4 w-3/5 -translate-x-1/2 rounded-[50%] bg-black/35 blur-md"
        />

        {/* Shoe image — lifts + scales on hover */}
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={shoe.image}
          alt={shoe.name}
          className="absolute inset-0 h-full w-full object-contain p-5 drop-shadow-[0_18px_28px_rgba(0,0,0,0.45)] transition-transform duration-500 ease-out group-hover:-translate-y-2 group-hover:scale-[1.06]"
        />

        {/* Featured badge */}
        <span className="absolute left-3 top-3 rounded-full bg-[rgb(var(--bg)/0.6)] px-2.5 py-1 text-[10px] font-medium uppercase tracking-widest text-[rgb(var(--fg))] backdrop-blur">
          Featured
        </span>

        {/* Shop Now — slides up on card hover */}
        <a
          href="#collections"
          className="absolute bottom-3 left-1/2 z-10 -translate-x-1/2 translate-y-14 rounded-full bg-[rgb(var(--fg)/0.9)] px-4 py-2 text-xs font-semibold text-[rgb(var(--bg))] opacity-0 backdrop-blur transition-all duration-300 hover:bg-[rgb(var(--fg))] group-hover:translate-y-0 group-hover:opacity-100"
        >
          Shop Now →
        </a>
      </div>

      {/* Meta */}
      <div className="flex items-center justify-between px-2 py-4">
        <div>
          <h3 className="font-medium">{shoe.name}</h3>
          <p className="text-sm text-[rgb(var(--muted))]">{shoe.tagline}</p>
        </div>
        <span className="font-display text-lg font-semibold">${shoe.price}</span>
      </div>

      {/* Spec chips */}
      <div className="flex flex-wrap gap-2 px-2 pb-2">
        {shoe.specs.map((s) => (
          <span
            key={s.label}
            className="rounded-full border border-[rgb(var(--border)/0.15)] bg-[rgb(var(--card)/0.5)] px-3 py-1 text-xs text-[rgb(var(--muted))]"
          >
            <span className="text-[rgb(var(--fg))]">{s.value}</span> {s.label}
          </span>
        ))}
      </div>
    </div>
  );
}

"use client";

import { useState, type FormEvent } from "react";
import { motion } from "framer-motion";
import { SplitText } from "@/components/ui/SplitText";
import { MagneticButton } from "@/components/ui/MagneticButton";

export function Newsletter() {
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState<"idle" | "done" | "error">("idle");

  const onSubmit = (e: FormEvent) => {
    e.preventDefault();
    // Basic client-side validation — no backend in this demo build.
    const valid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    if (!valid) {
      setStatus("error");
      return;
    }
    setStatus("done");
    setEmail("");
  };

  return (
    <section className="section-pad">
      <div className="container-x">
        <div className="relative overflow-hidden rounded-[2.5rem] border border-[rgb(var(--border)/0.12)] px-6 py-20 text-center md:px-16">
          {/* glow layers */}
          <div
            aria-hidden
            className="absolute inset-0 -z-10 opacity-80"
            style={{
              background:
                "radial-gradient(circle at 50% 120%, rgba(79,140,255,0.35), transparent 60%)",
            }}
          />
          <div
            aria-hidden
            className="absolute left-1/2 top-0 -z-10 h-40 w-40 -translate-x-1/2 rounded-full bg-neon/30 blur-[100px] animate-pulse-glow"
          />
          <div className="grid-lines absolute inset-0 -z-10 opacity-30" />

          <p className="eyebrow mx-auto mb-4 justify-center">
            <span className="h-1.5 w-1.5 rounded-full bg-neon" />
            Join the movement
          </p>
          <h2 className="heading-lg mx-auto max-w-2xl">
            <SplitText
              text="Be first to move beyond limits."
              by="words"
              onScroll
            />
          </h2>
          <p className="mx-auto mt-5 max-w-lg text-[rgb(var(--muted))]">
            Early access to drops, athlete stories and members-only pricing.
          </p>

          <form
            onSubmit={onSubmit}
            className="mx-auto mt-10 flex w-full max-w-md flex-col gap-3 sm:flex-row"
          >
            <label htmlFor="newsletter-email" className="sr-only">
              Email address
            </label>
            <input
              id="newsletter-email"
              type="email"
              required
              value={email}
              onChange={(e) => {
                setEmail(e.target.value);
                if (status !== "idle") setStatus("idle");
              }}
              placeholder="you@email.com"
              className="w-full flex-1 rounded-full border border-[rgb(var(--border)/0.2)] bg-[rgb(var(--card)/0.6)] px-5 py-3.5 text-sm outline-none backdrop-blur transition-colors placeholder:text-[rgb(var(--muted))] focus:border-electric focus:ring-2 focus:ring-electric/40"
              aria-invalid={status === "error"}
            />
            <MagneticButton type="submit" variant="primary">
              Subscribe
            </MagneticButton>
          </form>

          <div className="mt-4 h-5 text-sm" aria-live="polite">
            {status === "done" && (
              <motion.p
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-neon"
              >
                You’re in. Watch your inbox. ✓
              </motion.p>
            )}
            {status === "error" && (
              <motion.p
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-[#FF4D5E]"
              >
                Please enter a valid email address.
              </motion.p>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}

"use client";

import { useRef } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { TIMELINE } from "@/lib/data";
import { SplitText } from "@/components/ui/SplitText";
import { useReducedMotion } from "@/hooks/useReducedMotion";

export function Story() {
  const ref = useRef<HTMLDivElement>(null);
  const reduced = useReducedMotion();

  // Parallax the background layers against scroll progress.
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"],
  });
  const yBack = useTransform(scrollYProgress, [0, 1], ["-10%", "20%"]);
  const yFore = useTransform(scrollYProgress, [0, 1], ["10%", "-15%"]);
  const lineScale = useTransform(scrollYProgress, [0.1, 0.9], [0, 1]);

  return (
    <section
      id="story"
      ref={ref}
      className="relative overflow-hidden px-6 py-32 md:px-10 md:py-40 lg:px-16"
    >
      {/* Parallax backdrops */}
      <motion.div
        style={{ y: reduced ? 0 : yBack }}
        className="pointer-events-none absolute inset-0 -z-20"
      >
        <div className="grid-lines absolute inset-0 opacity-40" />
      </motion.div>
      <motion.div
        style={{ y: reduced ? 0 : yFore }}
        aria-hidden
        className="pointer-events-none absolute -right-20 top-40 -z-10 h-[40vh] w-[40vh] rounded-full opacity-30 blur-[120px]"
      >
        <div className="h-full w-full rounded-full bg-neon/40" />
      </motion.div>

      <div className="container-x">
        <div className="mx-auto mb-24 max-w-3xl text-center">
          <p className="eyebrow mx-auto mb-4 justify-center">
            <span className="h-1.5 w-1.5 rounded-full bg-neon" />
            Our story
          </p>
          <h2 className="heading-lg">
            <SplitText
              text="Built for the next kilometer"
              by="words"
              onScroll
            />
          </h2>
        </div>

        {/* Timeline */}
        <div className="relative mx-auto max-w-3xl">
          {/* animated vertical line */}
          <div className="absolute left-4 top-0 h-full w-px bg-[rgb(var(--border)/0.15)] md:left-1/2">
            <motion.div
              style={{ scaleY: reduced ? 1 : lineScale }}
              className="h-full w-full origin-top bg-gradient-to-b from-electric to-neon"
            />
          </div>

          <div className="flex flex-col gap-16">
            {TIMELINE.map((entry, i) => (
              <TimelineItem key={entry.year} entry={entry} index={i} />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function TimelineItem({
  entry,
  index,
}: {
  entry: (typeof TIMELINE)[number];
  index: number;
}) {
  const isLeft = index % 2 === 0;
  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.5 }}
      transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
      className={`relative flex flex-col gap-3 pl-14 md:w-1/2 md:pl-0 ${
        isLeft
          ? "md:self-start md:pr-14 md:text-right"
          : "md:self-end md:pl-14 md:text-left"
      }`}
    >
      {/* node */}
      <span
        className={`absolute left-4 top-1 h-3 w-3 -translate-x-1/2 rounded-full bg-neon shadow-glow-neon md:left-auto ${
          isLeft ? "md:-right-1.5 md:left-auto" : "md:-left-1.5"
        }`}
      />
      <span className="font-display text-5xl font-bold text-electric/30">
        {entry.year}
      </span>
      <h3 className="font-display text-2xl font-semibold">{entry.title}</h3>
      <p className="text-[rgb(var(--muted))]">{entry.body}</p>
    </motion.div>
  );
}

"use client";

import { useEffect, useRef, useState } from "react";
import Image from "next/image";

/**
 * Plan B — Multi-layer parallax tilt card.
 *
 * The shoe image sits on a card that rotates in 3D following the cursor
 * (CSS perspective + rotateX/rotateY). Multiple layers move at different
 * speeds creating a convincing depth illusion:
 *
 *   Layer 0 (glow)      — moves 2× faster than card   → feels closest
 *   Layer 1 (shoe img)  — fixed to card                → mid depth
 *   Layer 2 (logo)      — moves 1.5× slower            → feels furthest
 *   Layer 3 (glare)     — tracks cursor for sheen
 */
export function HeroTiltShoe() {
  const cardRef = useRef<HTMLDivElement>(null);
  const glareRef = useRef<HTMLDivElement>(null);

  // Normalised mouse -1 → 1 relative to the viewport
  const mouse = useRef({ x: 0, y: 0 });
  const current = useRef({ rotX: 0, rotY: 0, glareX: 50, glareY: 50 });
  const rafId = useRef<number>(0);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    setReady(true);

    const onMove = (e: MouseEvent) => {
      mouse.current.x = (e.clientX / window.innerWidth - 0.5) * 2;
      mouse.current.y = -(e.clientY / window.innerHeight - 0.5) * 2;
    };

    const onGyro = (e: DeviceOrientationEvent) => {
      mouse.current.x = Math.max(-1, Math.min(1, (e.gamma ?? 0) / 35));
      mouse.current.y = Math.max(-1, Math.min(1, ((e.beta ?? 0) - 20) / 35));
    };

    const tick = () => {
      const ease = 0.06;
      const card = cardRef.current;
      const glare = glareRef.current;
      if (!card || !glare) { rafId.current = requestAnimationFrame(tick); return; }

      const targetRotY = mouse.current.x * 18;  // max ±18° horizontal
      const targetRotX = mouse.current.y * 12;  // max ±12° vertical

      current.current.rotX += (targetRotX - current.current.rotX) * ease;
      current.current.rotY += (targetRotY - current.current.rotY) * ease;
      current.current.glareX += ((mouse.current.x * 50 + 50) - current.current.glareX) * ease;
      current.current.glareY += ((-mouse.current.y * 50 + 50) - current.current.glareY) * ease;

      card.style.transform = `
        perspective(900px)
        rotateX(${current.current.rotX}deg)
        rotateY(${current.current.rotY}deg)
        scale3d(1.04, 1.04, 1.04)
      `;

      // Glare follows cursor as a moving highlight
      glare.style.background = `radial-gradient(circle at ${current.current.glareX}% ${current.current.glareY}%, rgba(255,255,255,0.18) 0%, transparent 65%)`;

      // Parallax float for inner layers
      const depthX = current.current.rotY * 0.7;
      const depthY = -current.current.rotX * 0.7;
      const shoeEl = card.querySelector<HTMLElement>("[data-layer='shoe']");
      const glowEl = card.querySelector<HTMLElement>("[data-layer='glow']");
      const logoEl = card.querySelector<HTMLElement>("[data-layer='logo']");

      if (shoeEl) shoeEl.style.transform = `translate(${depthX * 1.4}px, ${depthY * 1.4}px)`;
      if (glowEl) glowEl.style.transform = `translate(${depthX * 2.5}px, ${depthY * 2.5}px)`;
      if (logoEl) logoEl.style.transform = `translate(${depthX * 0.5}px, ${depthY * 0.5}px)`;

      rafId.current = requestAnimationFrame(tick);
    };

    window.addEventListener("mousemove", onMove);
    window.addEventListener("deviceorientation", onGyro);
    rafId.current = requestAnimationFrame(tick);

    return () => {
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("deviceorientation", onGyro);
      cancelAnimationFrame(rafId.current);
    };
  }, []);

  return (
    <div className="absolute inset-0 flex items-center justify-center">
      {/* Outer wrapper keeps perspective origin centered */}
      <div
        className="relative"
        style={{ perspective: "900px", perspectiveOrigin: "50% 50%" }}
      >
        {/* ── The tilt card ── */}
        <div
          ref={cardRef}
          className="relative flex items-center justify-center"
          style={{
            width: "min(92vw, 820px)",
            height: "min(92vw, 820px)",
            transformStyle: "preserve-3d",
            willChange: "transform",
            transition: "transform 0.05s linear",
          }}
        >
          {/* Layer 0 — depth glow blob (moves fastest = feels closest) */}
          <div
            data-layer="glow"
            className="pointer-events-none absolute inset-0 rounded-full"
            style={{
              background:
                "radial-gradient(ellipse 60% 55% at 50% 55%, rgba(79,140,255,0.55) 0%, rgba(79,140,255,0.15) 50%, transparent 75%)",
              filter: "blur(32px)",
              transition: "transform 0.05s linear",
              willChange: "transform",
            }}
          />

          {/* Layer 1 — shoe image (mid depth, moves with card) */}
          <div
            data-layer="shoe"
            className="pointer-events-none absolute inset-0 flex items-center justify-center"
            style={{
              transition: "transform 0.05s linear",
              willChange: "transform",
              maskImage:
                "radial-gradient(ellipse 82% 78% at 50% 52%, #000 50%, transparent 88%)",
              WebkitMaskImage:
                "radial-gradient(ellipse 82% 78% at 50% 52%, #000 50%, transparent 88%)",
            }}
          >
            <Image
              src="/images/hero-poster.jpg"
              alt="Sisco sneaker"
              fill
              priority
              className="object-contain"
              style={{ opacity: 0.95 }}
            />
          </div>

          {/* Layer 2 — Sisco logo watermark (moves slowest = feels furthest back) */}
          <div
            data-layer="logo"
            className="pointer-events-none absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-1"
            style={{
              transition: "transform 0.05s linear",
              willChange: "transform",
            }}
          >
            <Image
              src="/images/logo.png"
              alt="Sisco"
              width={48}
              height={48}
              className="opacity-70"
              style={{ filter: "drop-shadow(0 0 8px rgba(79,140,255,0.8))" }}
            />
            <span
              className="text-[11px] font-bold tracking-[0.35em] text-white/60"
              style={{ textShadow: "0 0 10px rgba(79,140,255,0.6)" }}
            >
              SISCO
            </span>
          </div>

          {/* Layer 3 — glare highlight (tracks cursor) */}
          <div
            ref={glareRef}
            className="pointer-events-none absolute inset-0 rounded-2xl"
            style={{ mixBlendMode: "overlay" }}
          />

          {/* Edge rim — blue outline that brightens on tilt */}
          <div
            className="pointer-events-none absolute inset-0 rounded-2xl"
            style={{
              boxShadow:
                "inset 0 0 0 1px rgba(79,140,255,0.25), 0 0 60px -10px rgba(79,140,255,0.4), 0 40px 80px -20px rgba(0,0,0,0.6)",
            }}
          />
        </div>
      </div>
    </div>
  );
}

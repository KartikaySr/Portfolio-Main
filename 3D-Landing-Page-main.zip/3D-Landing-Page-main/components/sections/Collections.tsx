"use client";

import { useState } from "react";
import Image from "next/image";
import { AnimatePresence, motion } from "framer-motion";
import { PRODUCTS, type Product } from "@/lib/data";
import { Reveal } from "@/components/ui/Reveal";
import { SplitText } from "@/components/ui/SplitText";
import { MagneticButton } from "@/components/ui/MagneticButton";
import { useCart } from "@/components/providers/CartProvider";

export function Collections() {
  const [quickView, setQuickView] = useState<Product | null>(null);

  return (
    <section id="collections" className="section-pad relative">
      <div className="container-x">
        <div className="mb-14 flex flex-col items-start justify-between gap-6 md:flex-row md:items-end">
          <div>
            <p className="eyebrow mb-4">
              <span className="h-1.5 w-1.5 rounded-full bg-neon" />
              Collection
            </p>
            <h2 className="heading-lg">
              <SplitText text="The full lineup" by="words" onScroll />
            </h2>
          </div>
          <p className="max-w-sm text-[rgb(var(--muted))]">
            Six ways to move. Free shipping and 30-day returns on every pair.
          </p>
        </div>

        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {PRODUCTS.map((p, i) => (
            <Reveal key={p.id} direction="up" delay={(i % 3) * 0.08}>
              <ProductCard product={p} onQuickView={() => setQuickView(p)} />
            </Reveal>
          ))}
        </div>
      </div>

      {/* Quick view modal */}
      <AnimatePresence>
        {quickView && (
          <QuickViewModal
            product={quickView}
            onClose={() => setQuickView(null)}
          />
        )}
      </AnimatePresence>
    </section>
  );
}

function ProductCard({
  product,
  onQuickView,
}: {
  product: Product;
  onQuickView: () => void;
}) {
  const { addItem } = useCart();
  const [added, setAdded] = useState(false);

  const handleAdd = () => {
    addItem();
    setAdded(true);
    window.setTimeout(() => setAdded(false), 1400);
  };

  return (
    <div className="group relative overflow-hidden rounded-3xl border border-[rgb(var(--border)/0.1)] bg-[rgb(var(--card)/0.4)] p-3 transition-colors hover:border-[rgb(var(--border)/0.25)]">
      {/* Product photo on a gradient stage */}
      <div
        className="relative aspect-[4/3] overflow-hidden rounded-2xl"
        style={{
          background: `linear-gradient(135deg, ${product.gradient[0]}, ${product.gradient[1]})`,
        }}
      >
        {/* shine sweep on hover */}
        <span className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/25 to-transparent transition-transform duration-700 group-hover:translate-x-full" />

        {/* soft floor shadow under the shoe */}
        <span
          aria-hidden
          className="absolute bottom-4 left-1/2 h-4 w-3/5 -translate-x-1/2 rounded-[50%] bg-black/35 blur-md"
        />

        {/* real shoe cutout — lifts + scales on hover */}
        <Image
          src={product.image}
          alt={product.name}
          fill
          sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
          className="object-contain p-5 drop-shadow-[0_18px_28px_rgba(0,0,0,0.45)] transition-transform duration-500 ease-out group-hover:-translate-y-2 group-hover:scale-[1.06]"
        />

        <span className="absolute left-3 top-3 rounded-full bg-[rgb(var(--bg)/0.6)] px-2.5 py-1 text-[10px] font-medium uppercase tracking-widest text-[rgb(var(--fg))] backdrop-blur">
          {product.category}
        </span>

        {/* Quick view button appears on hover */}
        <button
          type="button"
          onClick={onQuickView}
          className="absolute bottom-3 left-1/2 z-10 -translate-x-1/2 translate-y-14 rounded-full bg-[rgb(var(--fg)/0.9)] px-4 py-2 text-xs font-semibold text-[rgb(var(--bg))] opacity-0 backdrop-blur transition-all duration-300 hover:bg-[rgb(var(--fg))] group-hover:translate-y-0 group-hover:opacity-100"
        >
          Quick View
        </button>
      </div>

      {/* Meta */}
      <div className="flex items-center justify-between px-2 py-4">
        <div>
          <h3 className="font-medium">{product.name}</h3>
          <p className="text-sm text-[rgb(var(--muted))]">${product.price}</p>
        </div>

        <button
          type="button"
          onClick={handleAdd}
          aria-label={`Add ${product.name} to cart`}
          className="relative flex h-10 items-center gap-2 overflow-hidden rounded-full bg-neon px-4 text-sm font-semibold text-ink transition-transform active:scale-95"
        >
          <AnimatePresence mode="wait" initial={false}>
            {added ? (
              <motion.span
                key="added"
                initial={{ y: 14, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                exit={{ y: -14, opacity: 0 }}
                className="flex items-center gap-1"
              >
                ✓ Added
              </motion.span>
            ) : (
              <motion.span
                key="add"
                initial={{ y: 14, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                exit={{ y: -14, opacity: 0 }}
              >
                Add +
              </motion.span>
            )}
          </AnimatePresence>
        </button>
      </div>
    </div>
  );
}

function QuickViewModal({
  product,
  onClose,
}: {
  product: Product;
  onClose: () => void;
}) {
  const { addItem } = useCart();

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      onClick={onClose}
      className="fixed inset-0 z-[150] grid place-items-center bg-black/70 p-4 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-label={`${product.name} quick view`}
    >
      <motion.div
        initial={{ scale: 0.9, y: 20, opacity: 0 }}
        animate={{ scale: 1, y: 0, opacity: 1 }}
        exit={{ scale: 0.9, y: 20, opacity: 0 }}
        transition={{ type: "spring", stiffness: 320, damping: 30 }}
        onClick={(e) => e.stopPropagation()}
        className="glass w-full max-w-3xl overflow-hidden rounded-3xl"
      >
        <div className="grid grid-cols-1 md:grid-cols-2">
          <div
            className="relative aspect-square"
            style={{
              background: `linear-gradient(135deg, ${product.gradient[0]}, ${product.gradient[1]})`,
            }}
          >
            <span
              aria-hidden
              className="absolute bottom-8 left-1/2 h-5 w-3/5 -translate-x-1/2 rounded-[50%] bg-black/35 blur-lg"
            />
            <Image
              src={product.image}
              alt={product.name}
              fill
              sizes="(max-width: 768px) 100vw, 384px"
              className="object-contain p-8 drop-shadow-[0_22px_36px_rgba(0,0,0,0.5)]"
            />
          </div>

          <div className="flex flex-col justify-center gap-4 p-8">
            <span className="eyebrow">{product.category}</span>
            <h3 className="font-display text-3xl font-semibold">
              {product.name}
            </h3>
            <p className="text-[rgb(var(--muted))]">
              Precision-tuned for daily performance with a nitrogen-infused
              UltraCush midsole and seamless AeroKnit upper.
            </p>
            <p className="font-display text-2xl font-semibold">
              ${product.price}
            </p>
            <div className="mt-2 flex gap-3">
              <MagneticButton
                variant="primary"
                onClick={() => {
                  addItem();
                  onClose();
                }}
              >
                Add to Cart
              </MagneticButton>
              <MagneticButton variant="ghost" onClick={onClose}>
                Close
              </MagneticButton>
            </div>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}

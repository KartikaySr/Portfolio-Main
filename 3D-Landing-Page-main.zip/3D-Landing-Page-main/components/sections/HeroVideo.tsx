"use client";

import { useEffect, useRef, useState } from "react";
import { useReducedMotion } from "@/hooks/useReducedMotion";

/**
 * Hero background video: the studio turntable render of the real Sisco sneaker.
 * Sits behind the headline. The clip is shot on a dark studio background, so we
 * feather the edges into the page and lean on blend + masks to make it read as
 * part of the scene rather than a boxed-in <video>.
 *
 * Under reduced-motion we render the static poster frame instead of autoplaying.
 */
export function HeroVideo() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const reduced = useReducedMotion();
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const v = videoRef.current;
    if (!v || reduced) return;
    // Ensure autoplay across browsers (muted + playsInline are set in markup).
    const tryPlay = () => v.play().catch(() => undefined);
    if (v.readyState >= 2) tryPlay();
    else v.addEventListener("loadeddata", tryPlay, { once: true });
    return () => v.removeEventListener("loadeddata", tryPlay);
  }, [reduced]);

  if (reduced) {
    // Static poster — no motion.
    return (
      <div className="absolute inset-0 flex items-center justify-center">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src="/images/hero-poster.jpg"
          alt="Sisco sneaker on a studio pedestal"
          className="h-full w-full object-cover opacity-90"
          style={{
            maskImage:
              "radial-gradient(ellipse 70% 70% at 50% 50%, #000 55%, transparent 85%)",
            WebkitMaskImage:
              "radial-gradient(ellipse 70% 70% at 50% 50%, #000 55%, transparent 85%)",
          }}
        />
      </div>
    );
  }

  return (
    <div className="absolute inset-0 flex items-center justify-center">
      <video
        ref={videoRef}
        className={`h-full w-full object-cover transition-opacity duration-700 ${
          ready ? "opacity-100" : "opacity-0"
        }`}
        style={{
          // Feather the video into the dark page on all sides.
          maskImage:
            "radial-gradient(ellipse 72% 72% at 50% 52%, #000 50%, transparent 84%)",
          WebkitMaskImage:
            "radial-gradient(ellipse 72% 72% at 50% 52%, #000 50%, transparent 84%)",
        }}
        autoPlay
        muted
        loop
        playsInline
        preload="auto"
        poster="/images/hero-poster.jpg"
        aria-hidden
        onCanPlay={() => setReady(true)}
      >
        <source src="/videos/hero-sneaker.webm" type="video/webm" />
        <source src="/videos/hero-sneaker.mp4" type="video/mp4" />
      </video>

      {/* Screen-blend sheen tint so the white shoe picks up brand color subtly */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 mix-blend-soft-light opacity-40"
        style={{
          background:
            "radial-gradient(circle at 50% 45%, rgba(79,140,255,0.35), transparent 60%)",
        }}
      />
    </div>
  );
}

"use client";

import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { NAV_LINKS } from "@/lib/data";
import { useCart } from "@/components/providers/CartProvider";
import Image from "next/image";

/**
 * Sticky top navigation. Becomes a compact glass bar after scrolling,
 * with a mobile drawer and animated cart badge.
 */
export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const { count } = useCart();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // Lock body scroll while the mobile menu is open.
  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  return (
    <motion.header
      initial={{ y: -80, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1], delay: 0.2 }}
      className="fixed inset-x-0 top-0 z-[120] flex justify-center px-4 pt-4"
    >
      <nav
        aria-label="Primary"
        className={[
          "container-x flex items-center justify-between rounded-2xl px-4 py-3 transition-all duration-500 md:px-6",
          scrolled ? "glass shadow-soft" : "border border-transparent bg-transparent",
        ].join(" ")}
      >
        <a
          href="#top"
          className="group flex items-center gap-2 text-lg font-semibold tracking-tightest"
        >
          <div className="relative h-8 w-8 overflow-hidden rounded-lg transition-transform duration-300 group-hover:rotate-12">
            <Image
              src="/images/logo.png"
              alt="Sisco Logo"
              fill
              priority
              className="object-cover scale-150"
            />
          </div>
          <span className="font-display text-[rgb(var(--fg))]">SISCO</span>
        </a>

        {/* Desktop links */}
        <ul className="hidden items-center gap-1 md:flex">
          {NAV_LINKS.map((link) => (
            <li key={link.href}>
              <a
                href={link.href}
                className="group relative rounded-full px-4 py-2 text-sm text-[rgb(var(--muted))] transition-colors hover:text-[rgb(var(--fg))]"
              >
                {link.label}
                <span className="absolute inset-x-4 bottom-1 h-px origin-left scale-x-0 bg-electric transition-transform duration-300 group-hover:scale-x-100" />
              </a>
            </li>
          ))}
        </ul>

        <div className="flex items-center gap-2 md:gap-3">
          <a
            href="https://github.com/Jishnu09-siuu/3D-Landing-Page#readme"
            target="_blank"
            rel="noopener noreferrer"
            title="View README Documentation"
            className="flex h-9 items-center gap-1.5 rounded-full border border-[rgb(var(--border)/0.2)] bg-[rgb(var(--card)/0.5)] px-3 text-xs font-medium backdrop-blur transition-colors hover:border-[rgb(var(--fg)/0.4)] text-[rgb(var(--muted))] hover:text-[rgb(var(--fg))]"
          >
            <svg
              className="h-4 w-4 fill-current"
              viewBox="0 0 24 24"
              aria-hidden="true"
            >
              <path fillRule="evenodd" clipRule="evenodd" d="M12 2C6.477 2 2 6.484 2 12.017c0 4.425 2.865 8.18 6.839 9.504.5.092.682-.217.682-.483 0-.237-.008-.868-.013-1.703-2.782.605-3.369-1.343-3.369-1.343-.454-1.158-1.11-1.466-1.11-1.466-.908-.62.069-.608.069-.608 1.003.07 1.53 1.032 1.53 1.032.892 1.53 2.341 1.088 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.113-4.555-4.951 0-1.093.39-1.988 1.029-2.688-.103-.253-.446-1.272.098-2.65 0 0 .84-.27 2.75 1.026A9.564 9.564 0 0112 6.844c.85.004 1.705.115 2.504.337 1.909-1.296 2.747-1.027 2.747-1.027.546 1.379.202 2.398.1 2.651.64.7 1.028 1.595 1.028 2.688 0 3.848-2.339 4.695-4.566 4.943.359.309.678.92.678 1.855 0 1.338-.012 2.419-.012 2.747 0 .268.18.58.688.482A10.019 10.019 0 0022 12.017C22 6.484 17.522 2 12 2z" />
            </svg>
            <span className="hidden sm:inline">README</span>
          </a>

          <button
            type="button"
            aria-label={`Cart, ${count} item${count === 1 ? "" : "s"}`}
            className="relative flex h-9 items-center gap-2 rounded-full border border-[rgb(var(--border)/0.2)] bg-[rgb(var(--card)/0.5)] px-3 text-sm backdrop-blur transition-colors hover:border-[rgb(var(--fg)/0.4)]"
          >
            <span aria-hidden>🛒</span>
            <AnimatePresence mode="popLayout">
              <motion.span
                key={count}
                initial={{ scale: 0.4, opacity: 0, y: -6 }}
                animate={{ scale: 1, opacity: 1, y: 0 }}
                exit={{ scale: 0.4, opacity: 0, y: 6 }}
                transition={{ type: "spring", stiffness: 600, damping: 24 }}
                className="min-w-[1.25rem] rounded-full bg-neon px-1 text-center text-xs font-bold text-ink"
              >
                {count}
              </motion.span>
            </AnimatePresence>
          </button>

          {/* Mobile menu toggle */}
          <button
            type="button"
            onClick={() => setOpen((o) => !o)}
            aria-expanded={open}
            aria-controls="mobile-menu"
            aria-label="Toggle navigation menu"
            className="flex h-9 w-9 flex-col items-center justify-center gap-1.5 rounded-full border border-[rgb(var(--border)/0.2)] bg-[rgb(var(--card)/0.5)] backdrop-blur md:hidden"
          >
            <span
              className={`h-0.5 w-4 bg-[rgb(var(--fg))] transition-transform ${open ? "translate-y-2 rotate-45" : ""}`}
            />
            <span
              className={`h-0.5 w-4 bg-[rgb(var(--fg))] transition-opacity ${open ? "opacity-0" : ""}`}
            />
            <span
              className={`h-0.5 w-4 bg-[rgb(var(--fg))] transition-transform ${open ? "-translate-y-2 -rotate-45" : ""}`}
            />
          </button>
        </div>
      </nav>

      {/* Mobile drawer */}
      <AnimatePresence>
        {open && (
          <motion.div
            id="mobile-menu"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 top-0 z-[110] flex flex-col bg-[rgb(var(--bg)/0.97)] px-8 pt-28 backdrop-blur-xl md:hidden"
          >
            <ul className="flex flex-col gap-2">
              {NAV_LINKS.map((link, i) => (
                <motion.li
                  key={link.href}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.05 * i + 0.1 }}
                >
                  <a
                    href={link.href}
                    onClick={() => setOpen(false)}
                    className="block border-b border-[rgb(var(--border)/0.1)] py-4 text-3xl font-display font-semibold tracking-tightest text-[rgb(var(--fg))]"
                  >
                    {link.label}
                  </a>
                </motion.li>
              ))}
            </ul>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.header>
  );
}

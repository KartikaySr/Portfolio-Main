"use client";

import {
  useRef,
  type ButtonHTMLAttributes,
  type ReactNode,
  type MouseEvent as ReactMouseEvent,
} from "react";
import { useReducedMotion } from "@/hooks/useReducedMotion";

type Variant = "primary" | "secondary" | "ghost";

type MagneticButtonProps = {
  children: ReactNode;
  variant?: Variant;
  /** Optional anchor href — renders an <a> styled as the button. */
  href?: string;
  strength?: number;
  className?: string;
} & ButtonHTMLAttributes<HTMLButtonElement>;

const VARIANTS: Record<Variant, string> = {
  primary:
    "bg-neon text-ink hover:shadow-glow-neon focus-visible:ring-neon/60",
  secondary:
    "bg-electric text-white hover:shadow-glow focus-visible:ring-electric/60",
  ghost:
    "bg-transparent text-[rgb(var(--fg))] ring-1 ring-inset ring-[rgb(var(--border)/0.25)] hover:ring-[rgb(var(--fg)/0.5)] focus-visible:ring-[rgb(var(--fg)/0.6)]",
};

/**
 * A button that magnetically drifts toward the cursor and emits a click ripple.
 * Falls back to a plain, fully-accessible button under reduced motion.
 */
export function MagneticButton({
  children,
  variant = "primary",
  href,
  strength = 0.35,
  className = "",
  ...props
}: MagneticButtonProps) {
  const ref = useRef<HTMLButtonElement>(null);
  const reduced = useReducedMotion();

  const handleMove = (e: ReactMouseEvent) => {
    if (reduced || !ref.current) return;
    const rect = ref.current.getBoundingClientRect();
    const x = e.clientX - (rect.left + rect.width / 2);
    const y = e.clientY - (rect.top + rect.height / 2);
    ref.current.style.transform = `translate(${x * strength}px, ${y * strength}px)`;
  };

  const handleLeave = () => {
    if (!ref.current) return;
    ref.current.style.transform = "translate(0, 0)";
  };

  const spawnRipple = (e: ReactMouseEvent) => {
    if (reduced || !ref.current) return;
    const rect = ref.current.getBoundingClientRect();
    const ripple = document.createElement("span");
    const size = Math.max(rect.width, rect.height);
    ripple.className =
      "pointer-events-none absolute rounded-full bg-white/30 animate-[ripple_0.6s_ease-out]";
    ripple.style.width = ripple.style.height = `${size}px`;
    ripple.style.left = `${e.clientX - rect.left - size / 2}px`;
    ripple.style.top = `${e.clientY - rect.top - size / 2}px`;
    ref.current.appendChild(ripple);
    window.setTimeout(() => ripple.remove(), 600);
  };

  const base =
    "group relative inline-flex items-center justify-center gap-2 overflow-hidden rounded-full px-7 py-3.5 text-sm font-semibold tracking-wide transition-[box-shadow,transform] duration-300 ease-out will-change-transform focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-offset-transparent";

  const content = (
    <>
      <span className="relative z-10 flex items-center gap-2">{children}</span>
      {/* inline keyframes for the ripple */}
      <style jsx>{`
        @keyframes ripple {
          to {
            transform: scale(2.4);
            opacity: 0;
          }
        }
      `}</style>
    </>
  );

  const classes = `${base} ${VARIANTS[variant]} ${className}`;

  if (href) {
    return (
      <a
        ref={ref as unknown as React.Ref<HTMLAnchorElement>}
        href={href}
        onMouseMove={handleMove}
        onMouseLeave={handleLeave}
        onMouseDown={spawnRipple}
        className={classes}
      >
        {content}
      </a>
    );
  }

  return (
    <button
      ref={ref}
      onMouseMove={handleMove}
      onMouseLeave={handleLeave}
      onMouseDown={spawnRipple}
      className={classes}
      {...props}
    >
      {content}
    </button>
  );
}

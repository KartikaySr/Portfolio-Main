"use client";

import { motion } from "framer-motion";
import { useTheme } from "@/components/providers/ThemeProvider";

/**
 * Accessible dark/light toggle with an animated thumb.
 */
export function ThemeToggle() {
  const { theme, toggleTheme } = useTheme();
  const isDark = theme === "dark";

  return (
    <button
      type="button"
      onClick={toggleTheme}
      aria-label={`Switch to ${isDark ? "light" : "dark"} mode`}
      aria-pressed={!isDark}
      className="relative flex h-9 w-16 items-center rounded-full border border-[rgb(var(--border)/0.2)] bg-[rgb(var(--card)/0.5)] px-1 backdrop-blur transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-electric"
    >
      <motion.span
        layout
        transition={{ type: "spring", stiffness: 500, damping: 32 }}
        className={[
          "flex h-7 w-7 items-center justify-center rounded-full text-xs",
          isDark ? "ml-0 bg-electric text-white" : "ml-auto bg-neon text-ink",
        ].join(" ")}
      >
        {isDark ? "☾" : "☀"}
      </motion.span>
    </button>
  );
}

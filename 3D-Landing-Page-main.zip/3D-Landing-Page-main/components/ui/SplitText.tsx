"use client";

import { useEffect, useRef, type ElementType } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { useReducedMotion } from "@/hooks/useReducedMotion";

// Register once at module load so scrollTrigger is always available, regardless
// of whether SmoothScrollProvider's effect has run yet. registerPlugin is
// idempotent, and this file is client-only so it never runs during SSR.
if (typeof window !== "undefined") {
  gsap.registerPlugin(ScrollTrigger);
}

type SplitTextProps = {
  text: string;
  /** Split into "words" or "chars". */
  by?: "words" | "chars";
  as?: ElementType;
  className?: string;
  delay?: number;
  stagger?: number;
  /** When true, animate on scroll into view instead of on mount. */
  onScroll?: boolean;
};

/**
 * Splits text into animated tokens that rise + fade into place. Each token is
 * wrapped in an overflow-hidden mask for a clean "reveal from below" effect.
 * Screen readers get the full string via an sr-only element; tokens are aria-hidden.
 */
export function SplitText({
  text,
  by = "words",
  as: Tag = "span",
  className = "",
  delay = 0,
  stagger = 0.05,
  onScroll = false,
}: SplitTextProps) {
  const ref = useRef<HTMLElement>(null);
  const reduced = useReducedMotion();

  useEffect(() => {
    if (reduced || !ref.current) return;
    const tokens = ref.current.querySelectorAll("[data-token]");
    gsap.set(tokens, { yPercent: 120 });

    const anim = gsap.to(tokens, {
      yPercent: 0,
      duration: 0.9,
      ease: "expo.out",
      stagger,
      delay,
      ...(onScroll
        ? {
            scrollTrigger: {
              trigger: ref.current,
              start: "top 85%",
              once: true,
            },
          }
        : {}),
    });

    return () => {
      anim.scrollTrigger?.kill();
      anim.kill();
    };
  }, [reduced, delay, stagger, onScroll, text]);

  const parts = by === "words" ? text.split(" ") : Array.from(text);

  return (
    <Tag ref={ref as never} className={className} aria-label={text}>
      {parts.map((part, i) => (
        <span
          key={`${part}-${i}`}
          aria-hidden
          className="inline-flex overflow-hidden align-bottom"
          style={{ paddingBottom: "0.06em" }}
        >
          <span data-token className="inline-block will-change-transform">
            {part === " " ? " " : part}
          </span>
          {by === "words" && i < parts.length - 1 ? " " : null}
        </span>
      ))}
    </Tag>
  );
}

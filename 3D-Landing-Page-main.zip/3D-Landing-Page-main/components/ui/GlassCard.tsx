"use client";

import { type ReactNode } from "react";

type GlassCardProps = {
  children: ReactNode;
  className?: string;
  /** Adds a subtle interactive lift + glow on hover. */
  interactive?: boolean;
};

/**
 * Glassmorphism surface with a faint top highlight and optional hover lift.
 */
export function GlassCard({
  children,
  className = "",
  interactive = false,
}: GlassCardProps) {
  return (
    <div
      className={[
        "glass relative overflow-hidden rounded-3xl",
        interactive
          ? "transition-transform duration-500 ease-out hover:-translate-y-1.5 hover:shadow-soft"
          : "",
        className,
      ].join(" ")}
    >
      {/* top edge highlight */}
      <span
        aria-hidden
        className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-[rgb(var(--fg)/0.2)] to-transparent"
      />
      {children}
    </div>
  );
}

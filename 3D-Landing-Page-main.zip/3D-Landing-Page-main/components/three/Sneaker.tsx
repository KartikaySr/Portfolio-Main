"use client";

import { useMemo, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import { RoundedBox } from "@react-three/drei";
import * as THREE from "three";

type SneakerProps = {
  /** Hex color for the dynamic upper — animates smoothly when it changes. */
  color?: string;
  /** Highlight accent (swoosh + details). */
  accent?: string;
  scale?: number;
};

/**
 * A fully procedural, stylized sneaker built from rounded primitives with PBR
 * materials. No external GLTF/Draco asset is required — the mesh is generated
 * in-engine so the site has zero missing-asset risk while still delivering
 * physically based lighting, reflections and shadows.
 *
 * The dominant upper color lerps toward the target each frame for buttery
 * colorway transitions.
 */
export function Sneaker({
  color = "#4F8CFF",
  accent = "#4F8CFF",
  scale = 1,
}: SneakerProps) {
  const group = useRef<THREE.Group>(null);
  const upperMat = useRef<THREE.MeshStandardMaterial>(null);
  const target = useMemo(() => new THREE.Color(color), [color]);

  // Smoothly interpolate the upper toward the requested colorway.
  useFrame(() => {
    target.set(color);
    if (upperMat.current) {
      upperMat.current.color.lerp(target, 0.12);
    }
  });

  // Shared material presets ------------------------------------------------
  const rubber = useMemo(
    () =>
      new THREE.MeshStandardMaterial({
        color: "#141414",
        roughness: 0.55,
        metalness: 0.1,
      }),
    []
  );
  const foam = useMemo(
    () =>
      new THREE.MeshStandardMaterial({
        color: "#f5f5f5",
        roughness: 0.85,
        metalness: 0,
      }),
    []
  );
  const accentMat = useMemo(
    () =>
      new THREE.MeshStandardMaterial({
        color: accent,
        roughness: 0.3,
        metalness: 0.2,
        emissive: new THREE.Color(accent),
        emissiveIntensity: 0.25,
      }),
    [accent]
  );

  return (
    <group ref={group} scale={scale} position={[0, -0.2, 0]} dispose={null}>
      {/* ---------------------------------------------------------------- */}
      {/* Outsole — dark rubber base                                       */}
      {/* ---------------------------------------------------------------- */}
      <RoundedBox
        args={[3.5, 0.22, 1.35]}
        radius={0.11}
        smoothness={4}
        position={[0, -0.62, 0]}
        castShadow
        receiveShadow
        material={rubber}
      />

      {/* Midsole — white foam wedge, thicker at the heel                  */}
      <RoundedBox
        args={[3.5, 0.42, 1.32]}
        radius={0.18}
        smoothness={4}
        position={[0, -0.38, 0]}
        castShadow
        material={foam}
      />
      {/* Heel wedge lift */}
      <RoundedBox
        args={[1.2, 0.3, 1.28]}
        radius={0.14}
        smoothness={4}
        position={[-1.05, -0.12, 0]}
        castShadow
        material={foam}
      />

      {/* ---------------------------------------------------------------- */}
      {/* Upper — dynamic color                                            */}
      {/* ---------------------------------------------------------------- */}
      <RoundedBox
        args={[2.9, 0.62, 1.16]}
        radius={0.28}
        smoothness={5}
        position={[-0.1, 0.12, 0]}
        castShadow
      >
        <meshStandardMaterial
          ref={upperMat}
          color={color}
          roughness={0.42}
          metalness={0.15}
        />
      </RoundedBox>

      {/* Toe cap — rounded front */}
      <mesh position={[1.35, -0.02, 0]} castShadow>
        <sphereGeometry args={[0.6, 32, 24]} />
        <meshStandardMaterial color={color} roughness={0.42} metalness={0.15} />
      </mesh>

      {/* Heel counter — rounded back */}
      <mesh position={[-1.5, 0.05, 0]} castShadow>
        <sphereGeometry args={[0.52, 32, 24]} />
        <meshStandardMaterial color={color} roughness={0.42} metalness={0.15} />
      </mesh>

      {/* Ankle collar opening */}
      <mesh position={[-0.85, 0.5, 0]} rotation={[Math.PI / 2, 0, 0]} castShadow>
        <torusGeometry args={[0.5, 0.14, 20, 40]} />
        <meshStandardMaterial color={color} roughness={0.5} metalness={0.1} />
      </mesh>

      {/* Tongue */}
      <RoundedBox
        args={[0.7, 0.5, 0.85]}
        radius={0.12}
        smoothness={4}
        position={[-0.15, 0.52, 0]}
        rotation={[0, 0, 0.35]}
        castShadow
        material={foam}
      />

      {/* ---------------------------------------------------------------- */}
      {/* Laces — evenly spaced across the throat                          */}
      {/* ---------------------------------------------------------------- */}
      {[0.35, 0.05, -0.25, -0.55].map((x, i) => (
        <mesh
          key={i}
          position={[x, 0.5, 0]}
          rotation={[Math.PI / 2, 0, 0]}
          castShadow
        >
          <cylinderGeometry args={[0.045, 0.045, 1.02, 12]} />
          <meshStandardMaterial color="#e8e8e8" roughness={0.9} />
        </mesh>
      ))}

      {/* Accent swoosh — a tapered strip on the side */}
      <mesh position={[0.05, 0.02, 0.6]} rotation={[0, 0, -0.18]} castShadow>
        <boxGeometry args={[2.1, 0.24, 0.06]} />
        <primitive object={accentMat} attach="material" />
      </mesh>
      <mesh position={[0.05, 0.02, -0.6]} rotation={[0, 0, -0.18]} castShadow>
        <boxGeometry args={[2.1, 0.24, 0.06]} />
        <primitive object={accentMat} attach="material" />
      </mesh>

      {/* Accent midsole pinstripe */}
      <mesh position={[0, -0.55, 0.68]}>
        <boxGeometry args={[3.4, 0.05, 0.02]} />
        <primitive object={accentMat} attach="material" />
      </mesh>
      <mesh position={[0, -0.55, -0.68]}>
        <boxGeometry args={[3.4, 0.05, 0.02]} />
        <primitive object={accentMat} attach="material" />
      </mesh>
    </group>
  );
}

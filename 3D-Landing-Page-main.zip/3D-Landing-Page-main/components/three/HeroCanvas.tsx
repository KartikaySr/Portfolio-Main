"use client";

import { Suspense, useRef } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import {
  ContactShadows,
  Environment,
  Float,
  Lightformer,
} from "@react-three/drei";
import * as THREE from "three";
import { Sneaker } from "./Sneaker";
import { Particles } from "./Particles";

/**
 * Hero shoe: continuous idle auto-rotation combined with a damped pointer
 * parallax, so the sneaker subtly follows the cursor without ever feeling jumpy.
 */
function HeroSneaker({ color, accent }: { color: string; accent: string }) {
  const group = useRef<THREE.Group>(null);
  const spin = useRef(0);

  useFrame((state, delta) => {
    if (!group.current) return;
    // Idle auto-rotation.
    spin.current += delta * 0.35;
    // Target orientation = spin + subtle pointer influence.
    const targetY = spin.current + state.pointer.x * 0.5;
    const targetX = -state.pointer.y * 0.25;
    group.current.rotation.y = THREE.MathUtils.lerp(
      group.current.rotation.y,
      targetY,
      0.08
    );
    group.current.rotation.x = THREE.MathUtils.lerp(
      group.current.rotation.x,
      targetX,
      0.08
    );
  });

  return (
    <Float speed={1.4} rotationIntensity={0.15} floatIntensity={0.6}>
      <group ref={group}>
        <Sneaker color={color} accent={accent} scale={1.05} />
      </group>
    </Float>
  );
}

/** Self-contained studio environment — no external HDR file required. */
function StudioEnvironment() {
  return (
    <Environment resolution={256}>
      <group rotation={[0, 0, 0]}>
        <Lightformer
          form="rect"
          intensity={3}
          position={[0, 4, -6]}
          scale={[10, 6, 1]}
          color="#ffffff"
        />
        <Lightformer
          form="rect"
          intensity={2}
          position={[-5, 1, 2]}
          scale={[6, 6, 1]}
          color="#4F8CFF"
        />
        <Lightformer
          form="rect"
          intensity={2}
          position={[5, 1, 2]}
          scale={[6, 6, 1]}
          color="#4F8CFF"
        />
        <Lightformer
          form="ring"
          intensity={1.5}
          position={[0, -3, 4]}
          scale={[4, 4, 1]}
          color="#ffffff"
        />
      </group>
    </Environment>
  );
}

type HeroCanvasProps = {
  color?: string;
  accent?: string;
};

/**
 * Full-screen hero 3D scene. Lazy-loaded by the Hero section so the heavy
 * three.js bundle never blocks first paint.
 */
export default function HeroCanvas({
  color = "#4F8CFF",
  accent = "#4F8CFF",
}: HeroCanvasProps) {
  return (
    <Canvas
      shadows
      dpr={[1, 2]}
      camera={{ position: [0, 0.5, 7], fov: 38 }}
      gl={{ antialias: true, alpha: true, powerPreference: "high-performance" }}
    >
      <Suspense fallback={null}>
        <ambientLight intensity={0.4} />
        <spotLight
          position={[5, 8, 5]}
          angle={0.3}
          penumbra={1}
          intensity={2.2}
          castShadow
          shadow-mapSize={[1024, 1024]}
        />
        <directionalLight position={[-5, 4, -3]} intensity={0.8} color="#4F8CFF" />

        <HeroSneaker color={color} accent={accent} />
        <Particles count={220} color={accent} />

        <ContactShadows
          position={[0, -1.35, 0]}
          opacity={0.5}
          scale={12}
          blur={2.8}
          far={4}
          resolution={512}
          color="#000000"
        />

        <StudioEnvironment />
      </Suspense>
    </Canvas>
  );
}

"use client";

import { Suspense, useRef, useState } from "react";
import { Canvas } from "@react-three/fiber";
import {
  ContactShadows,
  Environment,
  Float,
  Html,
  OrbitControls,
  Lightformer,
} from "@react-three/drei";
import type { OrbitControls as OrbitControlsImpl } from "three-stdlib";
import { Sneaker } from "./Sneaker";

type Spec = { label: string; value: string };

type ShowcaseShoeProps = {
  color: string;
  accent: string;
  specs: Spec[];
};

/**
 * Interactive product viewer:
 *  - Auto-rotates while idle
 *  - Pauses rotation while the user drags
 *  - Smoothly resumes shortly after release
 *  - Supports zoom + polar-limited orbit
 *  - Floats subtly and shows 3D-anchored floating spec labels
 */
export default function ShowcaseShoe({
  color,
  accent,
  specs,
}: ShowcaseShoeProps) {
  const controls = useRef<OrbitControlsImpl>(null);
  const resumeTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const [autoRotate, setAutoRotate] = useState(true);

  const handleStart = () => {
    if (resumeTimer.current) clearTimeout(resumeTimer.current);
    setAutoRotate(false);
  };

  const handleEnd = () => {
    if (resumeTimer.current) clearTimeout(resumeTimer.current);
    // Resume idle rotation a moment after the user lets go.
    resumeTimer.current = setTimeout(() => setAutoRotate(true), 1400);
  };

  return (
    <Canvas
      shadows
      dpr={[1, 1.5]}
      camera={{ position: [0, 0.6, 6.5], fov: 40 }}
      gl={{ antialias: true, alpha: true }}
    >
      <Suspense fallback={null}>
        <ambientLight intensity={0.5} />
        <spotLight
          position={[4, 7, 4]}
          angle={0.3}
          penumbra={1}
          intensity={2}
          castShadow
          shadow-mapSize={[1024, 1024]}
        />

        <Float speed={1.2} rotationIntensity={0.2} floatIntensity={0.5}>
          <group>
            <Sneaker color={color} accent={accent} scale={0.92} />

            {/* Floating spec labels anchored around the shoe */}
            {specs[0] && (
              <SpecLabel
                position={[1.9, 0.8, 0]}
                label={specs[0].label}
                value={specs[0].value}
                accent={accent}
              />
            )}
            {specs[1] && (
              <SpecLabel
                position={[-2.1, 0.2, 0]}
                label={specs[1].label}
                value={specs[1].value}
                accent={accent}
              />
            )}
            {specs[2] && (
              <SpecLabel
                position={[0.2, -1.4, 0]}
                label={specs[2].label}
                value={specs[2].value}
                accent={accent}
              />
            )}
          </group>
        </Float>

        <ContactShadows
          position={[0, -1.25, 0]}
          opacity={0.45}
          scale={10}
          blur={2.6}
          far={4}
          color="#000000"
        />

        <Environment resolution={128}>
          <Lightformer
            form="rect"
            intensity={3}
            position={[0, 4, -5]}
            scale={[8, 5, 1]}
            color="#ffffff"
          />
          <Lightformer
            form="rect"
            intensity={2}
            position={[-4, 1, 3]}
            scale={[5, 5, 1]}
            color={accent}
          />
        </Environment>

        <OrbitControls
          ref={controls}
          autoRotate={autoRotate}
          autoRotateSpeed={1.4}
          enablePan={false}
          enableDamping
          dampingFactor={0.08}
          minDistance={4.5}
          maxDistance={9}
          minPolarAngle={Math.PI / 3}
          maxPolarAngle={Math.PI / 1.7}
          onStart={handleStart}
          onEnd={handleEnd}
        />
      </Suspense>
    </Canvas>
  );
}

/** A small glass chip anchored in 3D space with a connector dot. */
function SpecLabel({
  position,
  label,
  value,
  accent,
}: {
  position: [number, number, number];
  label: string;
  value: string;
  accent: string;
}) {
  return (
    <Html position={position} center distanceFactor={8} zIndexRange={[10, 0]}>
      <div className="pointer-events-none flex select-none items-center gap-2 whitespace-nowrap rounded-full border border-white/15 bg-black/50 px-3 py-1.5 text-white backdrop-blur-md">
        <span
          className="h-1.5 w-1.5 rounded-full"
          style={{ backgroundColor: accent, boxShadow: `0 0 8px ${accent}` }}
        />
        <span className="text-[10px] uppercase tracking-widest text-white/60">
          {label}
        </span>
        <span className="text-xs font-semibold">{value}</span>
      </div>
    </Html>
  );
}

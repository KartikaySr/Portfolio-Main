"use client";

/**
 * Lightweight skeleton shown while a lazy 3D canvas loads. Purely CSS so it
 * adds no JS weight and appears instantly.
 */
export function CanvasFallback({ label = "Loading experience" }: { label?: string }) {
  return (
    <div
      role="status"
      aria-label={label}
      className="flex h-full w-full items-center justify-center"
    >
      <div className="relative h-24 w-24">
        <span className="absolute inset-0 animate-ping rounded-full bg-electric/20" />
        <span className="absolute inset-3 rounded-full border-2 border-electric/40 border-t-neon animate-spin" />
      </div>
    </div>
  );
}

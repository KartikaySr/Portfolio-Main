"use client";

import {
  createContext,
  useCallback,
  useContext,
  useState,
  type ReactNode,
} from "react";

type CartContextValue = {
  count: number;
  addItem: () => void;
};

const CartContext = createContext<CartContextValue | null>(null);

/**
 * Minimal in-memory cart. Only tracks a count — enough to drive the navbar
 * badge and the add-to-cart micro-interaction without a backend.
 */
export function CartProvider({ children }: { children: ReactNode }) {
  const [count, setCount] = useState(0);
  const addItem = useCallback(() => setCount((c) => c + 1), []);
  return (
    <CartContext.Provider value={{ count, addItem }}>
      {children}
    </CartContext.Provider>
  );
}

export function useCart(): CartContextValue {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error("useCart must be used within a CartProvider");
  return ctx;
}

"use client";

import { createContext, useContext, useEffect, type ReactNode } from "react";

type ThemeContextValue = {
  theme: "dark";
};

const ThemeContext = createContext<ThemeContextValue>({ theme: "dark" });

/**
 * Dark-only theme provider. Always keeps the site in dark mode.
 */
export function ThemeProvider({ children }: { children: ReactNode }) {
  // Ensure the `light` class is never present on <html>.
  useEffect(() => {
    document.documentElement.classList.remove("light");
  }, []);

  return (
    <ThemeContext.Provider value={{ theme: "dark" }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme(): ThemeContextValue {
  return useContext(ThemeContext);
}

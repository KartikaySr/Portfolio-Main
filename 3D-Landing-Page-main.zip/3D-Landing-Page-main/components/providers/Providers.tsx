"use client";

import { type ReactNode } from "react";
import { ThemeProvider } from "@/components/providers/ThemeProvider";
import { CartProvider } from "@/components/providers/CartProvider";
import { SmoothScrollProvider } from "@/components/providers/SmoothScrollProvider";

/** Single client boundary that composes every global provider. */
export function Providers({ children }: { children: ReactNode }) {
  return (
    <ThemeProvider>
      <CartProvider>
        <SmoothScrollProvider>{children}</SmoothScrollProvider>
      </CartProvider>
    </ThemeProvider>
  );
}

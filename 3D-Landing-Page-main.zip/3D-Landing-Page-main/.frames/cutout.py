import numpy as np
from PIL import Image
from rembg import remove, new_session
from scipy import ndimage

session = new_session("isnet-general-use")

JOBS = [
    ("airx_1.5.jpg", "sisco-airx-side.png"),
    ("velocity_1.5.jpg", "sisco-velocity-side.png"),
    ("nova_1.5.jpg", "sisco-nova-side.png"),
]

for src, out in JOBS:
    img = Image.open(f".frames/{src}").convert("RGBA")
    cut = remove(img, session=session, post_process_mask=True)
    arr = np.array(cut)
    alpha = arr[:, :, 3]

    # Hard alpha floor to kill faint checkerboard ghosts
    alpha = np.where(alpha < 130, 0, alpha)

    # Keep only the largest connected blob (the shoe) -> drops stray specks
    # like the Gemini sparkle if rembg left any fragment behind.
    mask = alpha > 0
    labels, n = ndimage.label(mask)
    if n > 1:
        sizes = ndimage.sum(mask, labels, range(1, n + 1))
        keep = np.argmax(sizes) + 1
        alpha = np.where(labels == keep, alpha, 0)

    arr[:, :, 3] = alpha.astype(np.uint8)
    result = Image.fromarray(arr, "RGBA")

    # Crop to the shoe's bounding box with a small margin
    bbox = result.getbbox()
    if bbox:
        x0, y0, x1, y1 = bbox
        m = 24
        x0 = max(0, x0 - m); y0 = max(0, y0 - m)
        x1 = min(result.width, x1 + m); y1 = min(result.height, y1 + m)
        result = result.crop((x0, y0, x1, y1))

    result.save(f"public/images/products/{out}")
    print(f"{out}: {result.size}")

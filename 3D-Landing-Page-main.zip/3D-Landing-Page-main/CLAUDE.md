# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Commands

```bash
npm run dev      # local dev server
npm run build    # production build
npm run lint     # ESLint via Next.js built-in config
npm start        # serve production build
```

There is no test runner configured in this project.

## Architecture

**Sisco** is a fully static, single-page Next.js 14 (App Router) marketing site for premium footwear. There is no backend, API routes, or database.

### Provider Tree

`app/layout.tsx` wraps the app in `components/Providers.tsx`, which composes three nested context providers:

```
ThemeProvider            → dark/light class toggle on <html>
  CartProvider           → in-memory cart (count + addItem only)
    SmoothScrollProvider → Lenis instance driven by gsap.ticker
```

`SmoothScrollProvider` is critical: it registers `ScrollTrigger`, creates Lenis, and syncs them so GSAP scroll-based animations stay in sync with smooth scrolling. It also respects `prefers-reduced-motion` via `hooks/useReducedMotion.ts`.

### Page Structure

`app/page.tsx` is the sole route — a sequence of section components rendered in order: `Preloader → CursorGlow → Navbar → Hero → Showcase → Technology → Collections → Story → Testimonials → Newsletter → Footer`.

### Data Layer

`lib/data.ts` is the single source of truth for all content. All section components import typed arrays from it (`FEATURED_SHOES`, `PRODUCTS`, `FEATURES`, `TESTIMONIALS`, `TIMELINE`, `NAV_LINKS`). To add or change content, edit only this file.

### 3D Layer

- `components/three/Sneaker.tsx` — a **fully procedural** sneaker built from Three.js geometry primitives (no GLTF/external 3D file). Upper color lerps frame-by-frame for smooth colorway transitions.
- `components/three/HeroCanvas.tsx` — R3F Canvas with studio lighting, contact shadows, `Float` idle drift, and cursor-parallax via `useFrame`.
- The current Hero uses `HeroTiltShoe` (CSS tilt card + static image) rather than `HeroCanvas`. Both implementations exist; the Three.js canvas is a wired alternate.

### Styling

Tailwind CSS v3 with a custom design token layer in `tailwind.config.ts`:
- Brand palette: `ink` (#0A0A0A), `paper` (#FFFFFF), `electric`/`neon` (#4F8CFF)
- Custom animations: `gradient-pan`, `float`, `pulse-glow`, `marquee`
- Custom shadows: `glow`, `glow-neon`, `soft`
- Fonts: Sora (`--font-display`) for headlines, Inter (`--font-sans`) for body — applied in `app/layout.tsx`

### UI Primitives

Reusable UI components live in `components/ui/`: `SplitText` (word/char animation), `Reveal` (scroll fade-in wrapper), `MagneticButton` (cursor-attracted CTA), `GlassCard` (glassmorphism primitive), `FloatingParticles`, `ThemeToggle`.

### Next.js Config

`next.config.mjs` transpiles the `three` package for Next.js's bundler and adds a webpack rule for GLSL shader files (`*.glsl`, `*.vert`, `*.frag`) as raw asset sources.

### Assets

- `assests/` (note the intentional typo in folder name) — raw source videos and extracted frames; `cutout.py` for background removal
- `public/images/` — processed product images and hero poster
- `public/videos/` — processed video assets

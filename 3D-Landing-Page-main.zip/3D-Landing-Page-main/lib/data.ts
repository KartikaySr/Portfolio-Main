/**
 * Central content + type definitions for the Sisco site.
 * Keeping data separate from components keeps sections declarative and reusable.
 */

export type ColorSwatch = {
  name: string;
  /** Hex used both for the UI swatch and the 3D material base color. */
  hex: string;
};

export type Shoe = {
  id: string;
  name: string;
  tagline: string;
  price: number;
  /** Base accent color for the 3D model. */
  colorways: ColorSwatch[];
  specs: { label: string; value: string }[];
  /** Poster / product image shown in the card. */
  image: string;
  /** Two-stop gradient used as the card backdrop behind the shoe. */
  gradient: [string, string];
  /** Video src (kept for potential future use). */
  video?: string;
  /** Video poster (kept for potential future use). */
  poster?: string;
};

export type Feature = {
  id: string;
  title: string;
  description: string;
  /** Small stat shown in the animated callout. */
  metric: string;
};

export type Product = {
  id: string;
  name: string;
  category: string;
  price: number;
  /** Transparent cutout of the real shoe photo. */
  image: string;
  /** Two-stop gradient used as the card backdrop behind the shoe. */
  gradient: [string, string];
};

export type Testimonial = {
  id: string;
  name: string;
  role: string;
  quote: string;
  rating: number;
  /** Initials rendered in the avatar chip. */
  initials: string;
  accent: string;
};

export type TimelineEntry = {
  year: string;
  title: string;
  body: string;
};

/* ------------------------------------------------------------------ */

export const FEATURED_SHOES: Shoe[] = [
  {
    id: "air-x",
    name: "Sisco Air X",
    tagline: "Weightless propulsion",
    price: 219,
    colorways: [
      { name: "Electric", hex: "#4F8CFF" },
      { name: "Sky", hex: "#38BDF8" },
      { name: "Mono", hex: "#F4F4F5" },
    ],
    specs: [
      { label: "Drop", value: "8mm" },
      { label: "Weight", value: "218g" },
      { label: "Plate", value: "Carbon" },
    ],
    image: "/images/showcase-airx-poster.jpg",
    gradient: ["#0f1f42", "#4F8CFF"],
    video: "/videos/showcase-airx",
    poster: "/images/showcase-airx-poster.jpg",
  },
  {
    id: "velocity",
    name: "Sisco Velocity",
    tagline: "Built for the sprint",
    price: 189,
    colorways: [
      { name: "Sky", hex: "#38BDF8" },
      { name: "Electric", hex: "#4F8CFF" },
      { name: "Crimson", hex: "#FF4D5E" },
    ],
    specs: [
      { label: "Drop", value: "6mm" },
      { label: "Weight", value: "196g" },
      { label: "Foam", value: "UltraCush" },
    ],
    image: "/images/showcase-velocity-poster.jpg",
    gradient: ["#1a0a0a", "#FF4D5E"],
    video: "/videos/showcase-velocity",
    poster: "/images/showcase-velocity-poster.jpg",
  },
  {
    id: "nova",
    name: "Sisco Nova",
    tagline: "Everyday orbit",
    price: 199,
    colorways: [
      { name: "Mono", hex: "#E7E7EA" },
      { name: "Electric", hex: "#4F8CFF" },
      { name: "Violet", hex: "#A78BFA" },
    ],
    specs: [
      { label: "Drop", value: "10mm" },
      { label: "Weight", value: "242g" },
      { label: "Mesh", value: "AeroKnit" },
    ],
    image: "/images/showcase-nova-poster.jpg",
    gradient: ["#1a0f2e", "#A78BFA"],
    video: "/videos/showcase-nova",
    poster: "/images/showcase-nova-poster.jpg",
  },
];

export const FEATURES: Feature[] = [
  {
    id: "foam",
    title: "Ultra Cushion Foam",
    description:
      "Nitrogen-infused midsole returns 87% of impact energy back into every stride.",
    metric: "87% return",
  },
  {
    id: "plate",
    title: "Carbon Flex Plate",
    description:
      "A full-length carbon plate stabilizes toe-off and channels force forward.",
    metric: "0.4mm plate",
  },
  {
    id: "mesh",
    title: "Breathable Mesh",
    description:
      "Engineered AeroKnit upper adapts to the foot while venting heat on contact.",
    metric: "-3°C surface",
  },
  {
    id: "light",
    title: "Lightweight Construction",
    description:
      "Fused seamless layers cut weight without giving up structural lockdown.",
    metric: "196g avg",
  },
];

export const PRODUCTS: Product[] = [
  {
    id: "p1",
    name: "Sisco Nova — Navy",
    category: "Lifestyle",
    price: 199,
    image: "/images/products/sisco-navy-lowtop.png",
    gradient: ["#1e293b", "#4F8CFF"],
  },
  {
    id: "p2",
    name: "Sisco Nova — Pine",
    category: "Lifestyle",
    price: 199,
    image: "/images/products/sisco-green-heel.png",
    gradient: ["#166534", "#22c55e"],
  },
  {
    id: "p3",
    name: "Sisco Summit — Rust",
    category: "High-top",
    price: 229,
    image: "/images/products/sisco-rust-hightop.png",
    gradient: ["#7c2d12", "#c2410c"],
  },
  {
    id: "p4",
    name: "Sisco Trail — Gum",
    category: "Everyday",
    price: 189,
    image: "/images/products/sisco-tan-gum.png",
    gradient: ["#78350f", "#d4a373"],
  },
  {
    id: "p5",
    name: "Sisco Field — Olive",
    category: "Everyday",
    price: 209,
    image: "/images/products/sisco-olive-top.png",
    gradient: ["#3f6212", "#65a30d"],
  },
  {
    id: "p6",
    name: "Sisco Court — Clay",
    category: "Heritage",
    price: 219,
    image: "/images/products/sisco-cream-lowtop.png",
    gradient: ["#44403c", "#ea7c4a"],
  },
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: "t1",
    name: "Maya Okafor",
    role: "Marathoner",
    quote:
      "The Air X feels like the road disappears. I shaved four minutes off my personal best in the first week.",
    rating: 5,
    initials: "MO",
    accent: "#4F8CFF",
  },
  {
    id: "t2",
    name: "Diego Ramírez",
    role: "Sprint coach",
    quote:
      "My athletes talk about the toe-off snap constantly. The carbon plate is the real deal.",
    rating: 5,
    initials: "DR",
    accent: "#38BDF8",
  },
  {
    id: "t3",
    name: "Aiko Tanaka",
    role: "Designer",
    quote:
      "It's the rare shoe I'd wear to a studio and a 10k. The silhouette is genuinely beautiful.",
    rating: 4,
    initials: "AT",
    accent: "#A78BFA",
  },
  {
    id: "t4",
    name: "Sam Whitfield",
    role: "Trail runner",
    quote:
      "Grip and lockdown on technical descents are unreal. Sisco clearly obsesses over detail.",
    rating: 5,
    initials: "SW",
    accent: "#FF4D5E",
  },
];

export const TIMELINE: TimelineEntry[] = [
  {
    year: "01",
    title: "The idea",
    body: "Sisco began with a simple question — what if performance never came at the cost of design?",
  },
  {
    year: "02",
    title: "The material",
    body: "Three years of foam chemistry produced UltraCush, our nitrogen-infused energy engine.",
  },
  {
    year: "03",
    title: "The shape",
    body: "Every curve is wind-tunnel tested and sculpted for motion, not the display shelf.",
  },
  {
    year: "04",
    title: "The future",
    body: "We build shoes for the next kilometer, the next record, the next version of you.",
  },
];

export const NAV_LINKS = [
  { label: "Showcase", href: "#showcase" },
  { label: "Technology", href: "#technology" },
  { label: "Collection", href: "#collections" },
  { label: "Story", href: "#story" },
];

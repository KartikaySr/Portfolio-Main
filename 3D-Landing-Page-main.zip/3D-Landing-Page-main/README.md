# 👟 Sisco — Premium Interactive 3D Footwear Landing Page

Sisco is a futuristic, highly interactive 3D web application and digital showroom designed for luxury & performance footwear. Built with Next.js 14, Three.js, React Three Fiber, GSAP, and Tailwind CSS.

---

## ✨ Features

- **🎨 3D Interactive Canvas**: Procedural 3D sneaker geometry rendered dynamically with realistic studio lighting, shadows, and smooth colorway transitions.
- **⚡ GSAP & Lenis Smooth Scroll**: Synchronized smooth-scrolling experience with scroll-triggered animations and reduced-motion access support.
- **🌓 Light & Dark Theme**: Built-in theme switcher with smooth transition effects.
- **🛍️ Interactive Product Showcase**: Dynamic shoe catalog with interactive hover cards, feature highlights, and video demonstrations.
- **🛒 In-Memory Shopping Cart**: State-managed cart provider for selecting product items and sizes.
- **📱 Fully Responsive Design**: Custom Tailwind layout tuned for mobile, tablet, and widescreen displays.

---

## 🛠️ Tech Stack

- **Framework**: [Next.js 14](https://nextjs.org/) (App Router)
- **Language**: [TypeScript](https://www.typescriptlang.org/)
- **3D Graphics**: [Three.js](https://threejs.org/), [@react-three/fiber](https://docs.pmnd.rs/react-three-fiber), [@react-three/drei](https://github.com/pmndrs/drei)
- **Animations**: [GSAP](https://gsap.com/) (ScrollTrigger), [Framer Motion](https://www.framer.com/motion/), [Lenis](https://lenis.darkroom.engineering/)
- **Styling**: [Tailwind CSS v3](https://tailwindcss.com/), PostCSS, Custom CSS Variables

---

## 🚀 Getting Started

### Prerequisites

Ensure you have [Node.js](https://nodejs.org/) (v18.x or higher) installed on your machine.

### Installation

1. **Clone the Repository:**
   ```bash
   git clone https://github.com/Jishnu09-siuu/3D-Landing-Page.git
   cd 3D-Landing-Page
   ```

2. **Install Dependencies:**
   ```bash
   npm install
   ```

3. **Run Development Server:**
   ```bash
   npm run dev
   ```

4. **Open in Browser:**
   Navigate to `http://localhost:3000` to view the application live.

---

## 📜 Available Scripts

In the project directory, you can run:

- `npm run dev` — Starts the development server at `http://localhost:3000`
- `npm run build` — Compiles and builds the production application
- `npm start` — Starts the production server after building
- `npm run lint` — Runs ESLint checks across the codebase

---

## 📁 Directory Structure

```text
3D-Landing-Page/
├── app/                  # Next.js 14 App Router layout & pages
├── components/           # Reusable UI components, layout sections, & 3D canvases
│   ├── providers/        # Theme, Cart, and Lenis/GSAP SmoothScroll context providers
│   ├── sections/         # Page section components (Hero, Showcase, Collections, etc.)
│   ├── three/            # Three.js canvas & procedural sneaker model components
│   └── ui/               # Modular UI primitives (GlassCard, Buttons, Cursor, Navbar)
├── hooks/                # Custom React hooks (e.g. useReducedMotion)
├── lib/                  # Centralized data store and helper functions
├── public/               # Static assets, models, and processed media
└── tailwind.config.ts    # Custom design tokens, animations, and color palettes
```

---

## 📄 License

This project is open source and available under the [MIT License](LICENSE).

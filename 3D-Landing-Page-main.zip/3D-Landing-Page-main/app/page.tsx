import { Navbar } from "@/components/ui/Navbar";
import { CursorGlow } from "@/components/ui/CursorGlow";
import { Preloader } from "@/components/ui/Preloader";
import { Hero } from "@/components/sections/Hero";
import { Showcase } from "@/components/sections/Showcase";
import { Technology } from "@/components/sections/Technology";
import { Collections } from "@/components/sections/Collections";
import { Story } from "@/components/sections/Story";
import { Testimonials } from "@/components/sections/Testimonials";
import { Newsletter } from "@/components/sections/Newsletter";
import { Footer } from "@/components/sections/Footer";

export default function Home() {
  return (
    <>
      <Preloader />
      <CursorGlow />
      <Navbar />

      {/* Skip link for keyboard users */}
      <a
        href="#showcase"
        className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[400] focus:rounded-full focus:bg-neon focus:px-4 focus:py-2 focus:text-ink"
      >
        Skip to content
      </a>

      <main>
        <Hero />
        <Showcase />
        <Technology />
        <Collections />
        <Story />
        <Testimonials />
        <Newsletter />
      </main>

      <Footer />
    </>
  );
}

import type { Metadata, Viewport } from "next";
import { Sora, Inter } from "next/font/google";
import "./globals.css";
import { Providers } from "@/components/providers/Providers";

// Bold display typeface + clean body typeface, exposed as CSS variables.
const display = Sora({
  subsets: ["latin"],
  weight: ["500", "600", "700", "800"],
  variable: "--font-display",
  display: "swap",
});

const sans = Inter({
  subsets: ["latin"],
  variable: "--font-sans",
  display: "swap",
});

export const metadata: Metadata = {
  title: "Sisco — Move Beyond Limits",
  description:
    "Sisco: performance engineered, style perfected. Premium running footwear with an immersive 3D experience.",
  keywords: ["Sisco", "sneakers", "running shoes", "performance footwear"],
  openGraph: {
    title: "Sisco — Move Beyond Limits",
    description: "Performance engineered. Style perfected.",
    type: "website",
  },
};

export const viewport: Viewport = {
  themeColor: "#0A0A0A",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className={`${display.variable} ${sans.variable}`}>
      <body className="font-sans antialiased">
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}

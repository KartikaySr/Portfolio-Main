/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  // three.js and its R3F ecosystem ship ESM; transpile for Next's server bundler.
  transpilePackages: ["three"],
  webpack: (config) => {
    // Allow importing GLSL-like assets if ever added; keeps shader tooling flexible.
    config.module.rules.push({
      test: /\.(glsl|vs|fs|vert|frag)$/,
      type: "asset/source",
    });
    return config;
  },
};

export default nextConfig;
